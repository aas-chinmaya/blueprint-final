import CauseDashboard from "@/modules/cause/causeDashboard";



export default function Page() {
  return (
    <>
      <div className="px-4 lg:px-6">
       <CauseDashboard/>
      </div>
    </>
  );
}
'use client';

import AddClient from '@/modules/clients/ClientOnboarding';
import React from 'react';

export default function ClientOnboarding() {
  return (
       <>
      
          
          <AddClient />
        
        </>
     
      
  );
}
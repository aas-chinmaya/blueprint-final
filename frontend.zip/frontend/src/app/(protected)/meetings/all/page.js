import ContactMeetingsManager from "@/modules/meetings/ContactMeetingsManager";


export default function Page() {
  return (
    <>
      

     <ContactMeetingsManager/>

    </>
  );
}
"use client";

import QuotationList from "@/modules/quotation/QuotationList";



export default function page() {
 

  return (
    <>
  
      <QuotationList/> 
    </>
  );
}

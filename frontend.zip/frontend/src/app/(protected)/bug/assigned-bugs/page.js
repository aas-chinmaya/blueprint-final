
import AllBugByEmployeeId from "@/modules/bug/AllBugByEmployeeId";

export default function Page() {


  return (
    <AllBugByEmployeeId/>
  );
}
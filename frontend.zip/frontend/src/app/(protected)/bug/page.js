import AllBugList from "@/modules/bug/AllBugList";

export default function Page() {


  return (
    <AllBugList/>
  );
}
"use client";

import Service from "@/modules/master/ServiceMaster";



export default function page() {
 

  return (
    <>
  
      <Service/> 
    </>
  );
}

// // // const fs = require('fs');
// // // const { google } = require('googleapis');
// // // const credentials = JSON.parse(fs.readFileSync('credentials.json'));

// // // const { client_secret, client_id, redirect_uris } = credentials.web;
// // // const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

// // // module.exports = oAuth2Client;
// // const fs = require('fs');
// // const path = require('path');
// // const { google } = require('googleapis');

// // const CREDENTIALS_PATH = path.join(__dirname, '../credentials/credentials.json');
// // const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH));
// // const { client_secret, client_id, redirect_uris } = credentials.web;

// // // ✅ Export as function
// // function getOAuth2Client() {
// //   return new google.auth.OAuth2(
// //     client_id,
// //     client_secret,
// //     redirect_uris[0] // should be http://localhost:3000/oauth2callback
// //   );
// // }

// // module.exports = { getOAuth2Client };
// const fs = require('fs');
// const path = require('path');
// const readline = require('readline');
// const { google } = require('googleapis');
 
// // const CREDENTIALS_PATH = path.join(__dirname, '../credentials/credentials.json');
// // const TOKEN_PATH = path.join(__dirname, '../credentials/token.json');
 
// // const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH));
// // const { client_secret, client_id, redirect_uris } = credentials.web;
 
// // const oAuth2Client = new google.auth.OAuth2(
// //   client_id,
// //   client_secret,
// //   redirect_uris[0]
// // );
 
// // if (!fs.existsSync(TOKEN_PATH)) {
// //   const authUrl = oAuth2Client.generateAuthUrl({
// //     access_type: 'offline',
// //     scope: ['https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/userinfo.email'],
// //   });
 
// //   console.log('Authorize this app by visiting this URL:\n', authUrl);
 
// //   const rl = readline.createInterface({
// //     input: process.stdin,
// //     output: process.stdout,
// //   });
 
// //   rl.question('\nEnter the code from that page here: ', (code) => {
// //     rl.close();
// //     oAuth2Client.getToken(code, (err, token) => {
// //       if (err) return console.error('Error retrieving access token:', err);
// //       oAuth2Client.setCredentials(token);
// //       fs.writeFileSync(TOKEN_PATH, JSON.stringify(token));
// //       console.log('✅ Token saved successfully!');
// //     });
// //   });
// // } else {
// //   const token = JSON.parse(fs.readFileSync(TOKEN_PATH));
// //   oAuth2Client.setCredentials(token);
// // }
 
// // module.exports = { oAuth2Client, google };
// const CREDENTIALS_PATH = path.join(__dirname, '../credentials/credentials.json');
// const TOKEN_PATH = path.join(__dirname, '../credentials/token.json');
 
// const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH));
// const { client_secret, client_id, redirect_uris } = credentials.web;
 
// const oAuth2Client = new google.auth.OAuth2(
//   client_id,
//   client_secret,
//   redirect_uris[0]
// );
 
// if (!fs.existsSync(TOKEN_PATH)) {
//   const authUrl = oAuth2Client.generateAuthUrl({
//     access_type: 'offline',
//     scope: ['https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/userinfo.email'],
//   });
 
//   console.log('Authorize this app by visiting this URL:\n', authUrl);
 
//   const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout,
//   });
 
//   rl.question('\nEnter the code from that page here: ', (code) => {
//     rl.close();
//     oAuth2Client.getToken(code, (err, token) => {
//       if (err) return console.error('Error retrieving access token:', err);
//       oAuth2Client.setCredentials(token);
//       fs.writeFileSync(TOKEN_PATH, JSON.stringify(token));
//       console.log('✅ Token saved successfully!');
//     });
//   });
// } else {
//   const token = JSON.parse(fs.readFileSync(TOKEN_PATH));
//   oAuth2Client.setCredentials(token);
// }
 
// module.exports = { oAuth2Client, google };



const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { google } = require('googleapis');

const CREDENTIALS_PATH = path.join(__dirname, '../credentials/credentials.json');
const TOKEN_PATH = path.join(__dirname, '../credentials/token.json');

const credentials = JSON.parse(fs.readFileSync(CREDENTIALS_PATH));
const { client_secret, client_id, redirect_uris } = credentials.web;

const oAuth2Client = new google.auth.OAuth2(
  client_id,
  client_secret,
  redirect_uris[0]
);
const REDIRECT_URI = 'http://localhost:8080/oauth2callback';
if (!fs.existsSync(TOKEN_PATH)) {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: 'offline',
      prompt: 'consent',
    scope: ['https://www.googleapis.com/auth/calendar', 'https://www.googleapis.com/auth/userinfo.email'],
     redirect_uri: REDIRECT_URI,
  });

  console.log('Authorize this app by visiting this URL:\n', authUrl);

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  rl.question('\nEnter the code from that page here: ', (code) => {
    rl.close();
    oAuth2Client.getToken(code, (err, token) => {
      if (err) return console.error('Error retrieving access token:', err);
      oAuth2Client.setCredentials(token);
      fs.writeFileSync(TOKEN_PATH, JSON.stringify(token));
      console.log('Token saved successfully!');
    });
  });
} else {
  const token = JSON.parse(fs.readFileSync(TOKEN_PATH));
  oAuth2Client.setCredentials(token);
}

module.exports = { oAuth2Client, google };
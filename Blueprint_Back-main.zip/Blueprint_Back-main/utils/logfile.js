// const winston = require('winston');
// require('winston-mongodb');
// const moment = require('moment');
// require('dotenv').config();

// // Get database URI from .env file
// const dbURI = process.env.MONGO_URI ;
// if (!dbURI) {
//   throw new Error('MONGO_URI is not defined in the environment variables');
// }

// // Generate unique Run ID and Timestamp
// const runId = moment().format('YYYY-MM-DD_HH-mm-ss-SSS');
// const runTimestamp = moment().format();

// // Create the logger instance
// const logger = winston.createLogger({
//   level: 'info',
//   format: winston.format.combine(
//     winston.format.timestamp(),
//     winston.format.simple()
//   ),

//   transports: [
  
//     // Log to MongoDB for errors
//     new winston.transports.MongoDB({
//       db: dbURI,
//       collection: 'error_logs',
//       level: 'error',
//       tryReconnect: true,
//     }),
//     // Console transport for development
//     new winston.transports.Console({
//       level: 'info',
//       format: winston.format.combine(
//         winston.format.colorize(),
//         winston.format.simple()
//       ),
//     }),
//   ],

//   exitOnError: false, 
// });

// // Add Run ID and Timestamp to logs
// logger.addMeta = (meta) => {
//   meta.runId = runId;
//   meta.runTimestamp = runTimestamp;
//   return meta;
// };

// // process.on('uncaughtException', (err) => {
// //   console.error('Uncaught Exception:', err);
// // });

// // process.on('unhandledRejection', (reason, promise) => {
// //   console.error('Unhandled Rejection:', reason);
// // });

// // module.exports = logger;

// // Handle uncaught exceptions and rejections
// process.on('uncaughtException', (err) => {
//   logger.error('Uncaught Exception', logger.addMeta({ stack: err.stack }));
//   process.exit(1);
// });

// process.on('unhandledRejection', (reason, promise) => {
//   logger.error('Unhandled Rejection', logger.addMeta({ reason: reason.toString(), promise }));
// });

// module.exports = logger;


const winston = require('winston');
require('winston-mongodb');
const moment = require('moment');
require('dotenv').config();

// Get database URI from .env file
const dbURI = process.env.MONGO_URI;
if (!dbURI) {
  throw new Error('MONGO_URI is not defined in the environment variables');
}

// Generate unique Run ID and Timestamp
const runId = moment().format('YYYY-MM-DD_HH-mm-ss-SSS');
const runTimestamp = moment().format();

// Create the logger instance
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json() // Structured logging for MongoDB
  ),
  transports: [
    // Log to MongoDB for errors
    new winston.transports.MongoDB({
      db: dbURI,
      collection: 'error_logs',
      level: 'error',
      tryReconnect: true,
      handleExceptions: true, // Log transport errors
    }),
    // Console transport for debugging
    new winston.transports.Console({
      level: 'info', // Log info and above (includes error)
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
  ],
  exitOnError: false,
});

// Add Run ID and Timestamp to logs
logger.addMeta = (meta) => {
  meta.runId = runId;
  meta.runTimestamp = runTimestamp;
  return meta;
};

// Handle uncaught exceptions and rejections
process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception', logger.addMeta({ stack: err.stack }));
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection', logger.addMeta({ reason: reason.toString(), promise }));
});

module.exports = logger;
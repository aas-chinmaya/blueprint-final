const Quotation = require('../Model/QuotationModel/QuotationModel');

module.exports = async function generateQuotationNumber() {
  const year = new Date().getFullYear();
  const count = await Quotation.countDocuments({}) + 1;
  const paddedCount = String(count).padStart(4, '0');
  return `QTN-${year}-${paddedCount}`;
};

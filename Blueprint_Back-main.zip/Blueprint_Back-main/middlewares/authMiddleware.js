

const jwt = require('jsonwebtoken');
const Session=require("../Model/HrmsModel/sessionModel");
const { log } = require('winston');
 

const validateToken = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    console.log(token);
    
    
    if (!token) {
      return res.status(401).json({ message: "Token not found." });
    }

    // Verify token
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
    req.user = decodedToken;

    // Check if session exists
    // const session = await Session.findOne({
    //   sessionToken: token,
    //   userId: decodedToken.id,
    // });

    // if (!session) {
    //   return res.status(401).json({ message: "Session expired. Please log in again." });
    // }

    // Proceed to next middleware
    next();
  } catch (error) {
    console.log(error);
    

    return res.status(403).json({
      message: process.env.TOKEN_INVALID || "Invalid token. Please log in again.",
    });
  }
};
 
module.exports = validateToken;


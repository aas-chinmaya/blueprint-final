const express = require('express');
const router = express.Router();
const {createQuotation,getQuotationByNumber,getClientStatusByQuotationId, getAllQuotations,getQuotationPDF,downloadQuotationPDF,handleStatusAction,renderStatusPage} = require('../../Controller/QuotationController/QuotationController');

// POST /api/quotations
router.post('/create', createQuotation);
router.get('/pdfbyqoutationnumber/:quotationNumber',  getQuotationPDF);
router.get('/pdf/download/:quotationNumber', downloadQuotationPDF);
router.post('/status/:quotationNumber/update', handleStatusAction);
router.get('/status/:quotationNumber', renderStatusPage);
router.get('/getAllquotations', getAllQuotations);  
router.get('/client-status-by-quotation/:quotationId', getClientStatusByQuotationId);  
router.get('/qoutationbynumber/:quotationNumber', getQuotationByNumber);  
// router.get('/getQuotationById/:id', getQuotationById);  
// router.put('/updatequotation/:id', updateQuotation);
// router.patch('/updatequotationstatus/:id', updateQuotationStatus);
// router.delete('/deletequotation/:id',deleteQuotation);

// [Extend] More routes like:
// GET /api/quotations/:id
// PUT /api/quotations/:id
// PATCH /api/quotations/:id/status
// DELETE /api/quotations/:id

module.exports = router;
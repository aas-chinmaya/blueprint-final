const express = require('express');
const router = express.Router();
const {createIndustry, getIndustries, getIndustryById, updateIndustry, deleteIndustry } = require('../../Controller/MasterController/industryController');

router.post('/createindustry', createIndustry);
router.get('/getindustry', getIndustries);
router.get('/IndustryById/:id', getIndustryById);
router.put('/updateIndustry/:id', updateIndustry);
router.delete('/deleteIndustry/:id',deleteIndustry);
module.exports = router;
const express = require('express');
const router = express.Router();
const {fetchBugsByAssignedTo,downloadBugsByAssigneeAndProject,downloadBugsByProject,createBug,resolveBug,getallbugs,getallbugByProjectId,getbugBybug_id}= require('../../Controller/BugController/bugController');
const validateToken=require("../../middlewares/authMiddleware");

router.post('/create', createBug);
router.put('/resolve/:bug_id', resolveBug);
router.get('/getallbugs', getallbugs);
router.get('/getallbugByProjectId/:projectId', getallbugByProjectId);
router.get('/getbugBybug_id/:bug_id', getbugBybug_id);
// GET /api/bugs/assigned/:assignedTo
router.get('/assigned/:assignedTo', fetchBugsByAssignedTo);
 router.get('/download/:projectId', downloadBugsByProject);
router.get('/download-by-assignee/:projectId/:assignedTo',downloadBugsByAssigneeAndProject );
module.exports = router;
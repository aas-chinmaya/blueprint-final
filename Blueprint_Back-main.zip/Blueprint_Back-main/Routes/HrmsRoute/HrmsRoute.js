const express = require("express");
const router = express.Router();
const validateToken=require("../../middlewares/authMiddleware");
const {    checkToken,getUserByEmailFromCookie, getAllHRMSEmployees ,fetchAllUsers,sendOtpForLogin,verifyLoginOTP,getUserByEmail, logout,logoutAllDevices } = require("../../Controller/HrmsController/HrmsController");

router.get("/employees", getAllHRMSEmployees);
router.get("/fetchAllUsers",fetchAllUsers);

router.post("/login", sendOtpForLogin);
router.post("/verifyOtp", verifyLoginOTP);
router.get("/getUserByEmail/:email",getUserByEmail);
router.post("/logout",logout);
router.post("/logoutAllDevices",logoutAllDevices);

router.get("/user/profile", getUserByEmailFromCookie);
router.post('/checkCookies', checkToken);
module.exports = router;

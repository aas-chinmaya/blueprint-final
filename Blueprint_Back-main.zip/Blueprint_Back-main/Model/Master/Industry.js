const mongoose = require('mongoose');

const IndustrySchema = new mongoose.Schema({
  industryId: { type: String,  unique: true },
  Industryname: { type: String, required: true },
  
  
}, { timestamps: true });
IndustrySchema.statics.createServiceWithId = async function (industryData) {
  const lastIndustry = await this.findOne().sort({ createdAt: -1 });

  let nextId = 1;
  if (lastIndustry && lastIndustry.industryId) {
    const lastNum = parseInt(lastIndustry.industryId.split('-')[1]);
    nextId = lastNum + 1;
  }

  const industryId = `Ind-${String(nextId).padStart(3, '0')}`;

  const newIndustry = new this({
    industryId,
    ...industryData
  });

  return newIndustry.save();
};

module.exports = mongoose.model('Industry', IndustrySchema)
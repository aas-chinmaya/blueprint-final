
const mongoose = require('mongoose');
 
const momSchema = new mongoose.Schema({
  momId: { type: String, required: true, unique: true },
  meetingId: { type: String},
  date: { type: String },
  time: { type: String },
  agenda: { type: String },
  meetingMode: { type: String },
  duration: { type: String },
  participants: [{ type: String }],
  summary: { type: String },
  notes: { type: String },
  
  signature: { type: String },
  status: {
    type: String,
    enum: ['draft', 'final'],
    default: 'final'
  },
  createdBy: { type: String },
   pdf: Buffer,
  pdfUrl: String
}, 


{ timestamps: true });
 
module.exports = mongoose.model('Mom', momSchema);




const mongoose = require("mongoose");

const PaymentStatusSchema = new mongoose.Schema({
  contactId: String,
  contactEmail: String,
  amount: Number,
  paymentLink: String,
  status: {
    type: String,
    enum: ['paid', 'unpaid'],
    default: 'unpaid'
  },
  statusCode:{type:String},
  paymentId: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("PaymentStatus", PaymentStatusSchema);
const mongoose = require('mongoose');
 
const clientSchema = new mongoose.Schema({
  clientId: { type: String, unique: true },
  clientName: { type: String, required: true },
  industryType: { type: String },
  contactPersonName: { type: String },
  contactEmail: { type: String, required: true },
  contactNo: { type: String, required: true },
  address: { type: String, required: true },
  onboardingDate: { type: Date, required: true },
  website: { type: String },
  fileData: [{
    data: Buffer,
    contentType: String,
    fileName: String
  }],
  Onboardedstatus: {
    type: String,
    enum: ['onboard', 'notonboard'],
    default: 'notonboard'
  },
  isDeleted: { type: Boolean, default: false }
}, { timestamps: true });
 
module.exports = mongoose.model('Client', clientSchema);
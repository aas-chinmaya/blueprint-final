// const mongoose = require('mongoose');

// const taskSchema = new mongoose.Schema({
//   title: { type: String, required: true },
//   description: { type: String },
//   assignedTo: { type: String },
//   projectId: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
//   projectName: { type: String },
//   assignedBy: { type: String },
//   priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
//   deadline: { type: Date },
//   status: { type: String, enum: ['Pending', 'In Progress', 'Completed'], default: 'Pending' },
//   createdAt: { type: Date, default: Date.now }
// });

// module.exports = mongoose.model('Task', taskSchema);



// const mongoose = require('mongoose');
// const Bug = require('../BugModel/Bug');
 
 
 
// const taskSchema = new mongoose.Schema({
//   task_id: { type: String, unique: true },
//   projectId: { type: String, required: true, ref: 'Project' },
//   projectName: { type: String, required: true, ref: 'Project' },
//   title: { type: String, required: true },
//   description: { type: String },
//   assignedTo: { type: String },
//   assignedBy: { type: String },
//   priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
//   deadline: { type: Date },
//   memberId:{type: String},
//   status: { type: String, enum: ['Pending', 'In Progress', 'Completed'], default: 'Pending' },
//   createdAt: { type: Date, default: Date.now },
//   isDeleted: { type: Boolean, default: false },
 
//   completedAt: { type: Date },
//   isLate: { type: Boolean, default: false },
//   completionFeedback: { type: String } ,// Required only if isLate is true
//   submittedBy: { type: String },
//   submittedAt: { type: Date },
//   reviewedBy: { type: String },
//   reviewStatus: { type: String, enum: ['Accepted', 'ConvertedToBug','pending'], default: 'pending' },
//   bugIds: [{ type: String, ref: 'Bug' }]
// });
 
 
// // Static method to safely generate next task_id even after deletions
// taskSchema.statics.createTaskWithId = async function (taskData) {
//   const lastTask = await this.findOne().sort({ createdAt: -1 });
 
//   let nextId = 1;
//   if (lastTask && lastTask.task_id) {
//     const lastIdNum = parseInt(lastTask.task_id.split('-')[1]);
//     nextId = lastIdNum + 1;
//   }
 
//   const task_id = `TASK-${String(nextId).padStart(3, '0')}`;
 
//   const newTask = new this({
//     task_id,
//     ...taskData
//   });
 
//   return newTask.save();
// };
 
// module.exports = mongoose.model('Task', taskSchema);
const mongoose = require('mongoose');
const Bug = require('../BugModel/Bug');
 
 
 
const taskSchema = new mongoose.Schema({
  task_id: { type: String, unique: true },
  projectId: { type: String, required: true, ref: 'Project' },
  projectName: { type: String, required: true, ref: 'Project' },
  title: { type: String, required: true },
  description: { type: String },
  assignedTo: { type: String },
  assignedBy: { type: String },
  priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
  deadline: { type: Date },
  memberId:{type: String},
  status: { type: String, enum: ['Pending', 'In Progress', 'Completed'], default: 'Pending' },
  createdAt: { type: Date, default: Date.now },
  isDeleted: { type: Boolean, default: false },
 
  completedAt: { type: Date },
  isLate: { type: Boolean, default: false },
  // completionFeedback: { type: String } ,
   delayReason: { type: String } ,// // Required only if isLate is true
  submittedBy: { type: String },
  submittedAt: { type: Date },
  reviewedBy: { type: String },
  reviewStatus: {
  type: String,
  enum: ['N/A', 'InReview', 'BugReported', 'Resolved'],
  default: 'N/A',
},
 
  // reviewStatus: { type: String, enum: ['Accepted', 'ConvertedToBug','pending'], default: 'pending' },
  bugIds: [{ type: String, ref: 'Bug' }],
    taskHistory: [{
    action: { type: String }, // 'Task Created', 'Bug Reported', etc.
    timestamp: { type: Date, default: Date.now },
    reviewStatus: { type: String },
    bug_id: { type: String },
    bugTitle: { type: String },
    bugStatus: { type: String }
  }]
 
});
 
 
// Static method to safely generate next task_id even after deletions
taskSchema.statics.createTaskWithId = async function (taskData) {
  const lastTask = await this.findOne().sort({ createdAt: -1 });
 
  let nextId = 1;
  if (lastTask && lastTask.task_id) {
    const lastIdNum = parseInt(lastTask.task_id.split('-')[1]);
    nextId = lastIdNum + 1;
  }
 
  const task_id = `TASK-${String(nextId).padStart(3, '0')}`;
 
  const newTask = new this({
    task_id,
    ...taskData
  });
 
  return newTask.save();
};
 
module.exports = mongoose.model('Task', taskSchema);




// taskSchema.methods.checkAndMarkTaskAsCompleted = async function () {
//   const bugs = await Bug.find({ taskRef: this.task_id });
 
//   // If all bugs are resolved, mark the task as completed
//   const allBugsResolved = bugs.every(bug => bug.status === 'Resolved');
 
//   if (allBugsResolved) {
//     this.status = 'Completed';
//     this.completedAt = new Date();
//     await this.save();
//   }
// };
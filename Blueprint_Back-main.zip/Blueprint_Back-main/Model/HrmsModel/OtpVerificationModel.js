const mongoose = require("mongoose");

const otpVerificationSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        index: true,
    },
    loginOTP: {
        type: String,
        required: true,
    },
    tokenExpireTime: {
        type: Number,
        required: true,
    },
    failedAttempts: {
        type: Number,
        default: 0,
    },
    freezeUntil: {
        type: Number,
        default: null,
    },
    createdAt: {
        type: Date,
        default: Date.now,
        expires: 600, // Auto-delete after 10 minutes
    },
});

module.exports = (connection) =>
  connection.model("OtpVerification", otpVerificationSchema);
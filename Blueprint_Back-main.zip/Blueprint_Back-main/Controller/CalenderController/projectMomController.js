//  const path = require('path');
// const Mom = require('../../Model/CalenderModel/ProjectMomModel');
// const Project=require('../../Model/ProjectModel/projectModel')
// const generateProjectMomPDF = require('../../utils/ProjectpdfGenerator');

// const UserToken = require("../../Model/CalenderModel/userTokenModel");
// const fs = require('fs');
// const moment = require("moment");

// // exports.createProjectMOM = async (req, res) => {
// //   try {
// //     const {
// //       projectName,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       summary,
// //       notes,
// //       createdBy,
// //       status // draft / final
// //     } = req.body;

// //     //  Validate required fields
// //     if (!projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
// //       return res.status(400).json({ message: "Missing required fields" });
// //     }

// //     //  Handle signature upload
// //     const signatureBuffer = req.file?.buffer || null;
// //     const signatureMimeType = req.file?.mimetype || "";

// //     //  Generate sequential momId: AAS-IT-MOM-PROJECTNAME-001
// //     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();
// //     const momCount = await Mom.countDocuments({ projectName });
// //     const sequence = String(momCount + 1).padStart(3, "0");
// //     const momId = `AAS-IT-MOM-${projectKey}-${sequence}`;

// //     const baseUrl = `${req.protocol}://${req.get("host")}`;
// //     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;

// //     let signatureRelativePath = null;

// //     if (signatureBuffer) {
// //       const allowedTypes = {
// //         "image/jpeg": "jpg",
// //         "image/png": "png"
// //       };
// //       const extension = allowedTypes[signatureMimeType];
// //       if (!extension) {
// //         return res.status(400).json({ message: "Unsupported signature file type" });
// //       }

// //       const signatureFolder = path.join("uploads", "signatures");
// //       const signatureFilename = `${momId}-signature.${extension}`;
// //       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);

// //       if (!fs.existsSync(signatureDir)) {
// //         fs.mkdirSync(signatureDir, { recursive: true });
// //       }

// //       const signaturePath = path.join(signatureDir, signatureFilename);
// //       fs.writeFileSync(signaturePath, signatureBuffer);

// //       signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
// //     }

// //     // Create new Project MOM
// //     const now = new Date();
// //     const formattedDate = now.toISOString().split("T")[0];
// //     const formattedTime = now.toTimeString().split(" ")[0];

// //     const momData = {
// //       momId,
// //       projectName,
// //       date: formattedDate,
// //       time: formattedTime,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       participants: [],
// //       summary,
// //       notes,
// //       createdBy,
// //       signature: signatureRelativePath,
// //       attachmentUrl,
// //       status
// //     };

// //     if (status === "final") {
// //       const pdfBuffer = await generateProjectMomPDF(momData);
// //       const pdfFilename = `${momId}.pdf`;
// //       const pdfDir = path.resolve(__dirname, "../../uploads/moms");

// //       if (!fs.existsSync(pdfDir)) {
// //         fs.mkdirSync(pdfDir, { recursive: true });
// //       }

// //       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
// //       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
// //     }

// //     const savedMom = await Mom.create(momData);

// //     return res.status(200).json({
// //       message: status === "draft" ? "Project MoM saved as draft" : "Project MoM created successfully",
// //       mom: savedMom,
// //       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
// //     });
// //   } catch (err) {
// //     console.error("Error:", err);
// //     return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
// //   }
// // };

// // exports.createProjectMOM = async (req, res) => {
// //   try {
// //     const {
// //       projectName,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       summary,
// //       notes,
// //       createdBy,
// //       status // draft / final
// //     } = req.body;

// //     // ✅ Validate required fields
// //     if (!projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
// //       return res.status(400).json({ message: "Missing required fields" });
// //     }

// //     // ✅ Handle signature upload
// //     const signatureBuffer = req.file?.buffer || null;
// //     const signatureMimeType = req.file?.mimetype || "";

// //     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();

// //     // ✅ Check if there's already a draft for this project
// //     let existingMom = await Mom.findOne({ projectName, status: "draft" });

// //     let momId;
// //     if (existingMom) {
// //       // Use existing draft momId
// //       momId = existingMom.momId;
// //     } else {
// //       // Generate new sequential momId
// //       const momCount = await Mom.countDocuments({ projectName });
// //       const sequence = String(momCount + 1).padStart(3, "0");
// //       momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
// //     }

// //     const baseUrl = `${req.protocol}://${req.get("host")}`;
// //     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;

// //     let signatureRelativePath = null;

// //     if (signatureBuffer) {
// //       const allowedTypes = {
// //         "image/jpeg": "jpg",
// //         "image/png": "png"
// //       };
// //       const extension = allowedTypes[signatureMimeType];
// //       if (!extension) {
// //         return res.status(400).json({ message: "Unsupported signature file type" });
// //       }

// //       const signatureFolder = path.join("uploads", "signatures");
// //       const signatureFilename = `${momId}-signature.${extension}`;
// //       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);

// //       if (!fs.existsSync(signatureDir)) {
// //         fs.mkdirSync(signatureDir, { recursive: true });
// //       }

// //       const signaturePath = path.join(signatureDir, signatureFilename);
// //       fs.writeFileSync(signaturePath, signatureBuffer);

// //       signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
// //     }

// //     const now = new Date();
// //     const formattedDate = now.toISOString().split("T")[0];
// //     const formattedTime = now.toTimeString().split(" ")[0];

// //     const momData = {
// //       momId,
// //       projectName,
// //       date: formattedDate,
// //       time: formattedTime,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       participants: [],
// //       summary,
// //       notes,
// //       createdBy,
// //       signature: signatureRelativePath || existingMom?.signature,
// //       attachmentUrl,
// //       status
// //     };

// //     if (status === "final") {
// //       const pdfBuffer = await generateProjectMomPDF(momData);
// //       const pdfFilename = `${momId}.pdf`;
// //       const pdfDir = path.resolve(__dirname, "../../uploads/moms");

// //       if (!fs.existsSync(pdfDir)) {
// //         fs.mkdirSync(pdfDir, { recursive: true });
// //       }

// //       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
// //       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
// //     }

// //     let savedMom;
// //     if (existingMom) {
// //       // 🔄 Update existing draft
// //       Object.assign(existingMom, momData);
// //       savedMom = await existingMom.save();
// //     } else {
// //       // 🆕 Create new
// //       savedMom = await Mom.create(momData);
// //     }

// //     return res.status(200).json({
// //       message: status === "draft" ? "Project MoM saved as draft" : "Project MoM finalized successfully",
// //       mom: savedMom,
// //       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
// //     });
// //   } catch (err) {
// //     console.error("Error:", err);
// //     return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
// //   }
// // };
// // exports.createProjectMOM = async (req, res) => {
// //   try {
// //     const {
// //       projectId,   // ✅ Added
// //       projectName,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       summary,
// //       notes,
// //       createdBy,
// //       status // draft / final
// //     } = req.body;
 
// //     // ✅ Validate required fields
// //     if (!projectId || !projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
// //       return res.status(400).json({ message: "Missing required fields" });
// //     }
 
// //     // ✅ Handle signature upload
// //     const signatureBuffer = req.file?.buffer || null;
// //     const signatureMimeType = req.file?.mimetype || "";
 
// //     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();
 
// //     // ✅ Check if there's already a draft for this project
// //     let existingMom = await Mom.findOne({ projectId, status: "draft" });
 
// //     let momId;
// //     if (existingMom) {
// //       // Use existing draft momId
// //       momId = existingMom.momId;
// //     } else {
// //       // Generate new sequential momId
// //       const momCount = await Mom.countDocuments({ projectId });
// //       const sequence = String(momCount + 1).padStart(3, "0");
// //       momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
// //     }
 
// //     const baseUrl = `${req.protocol}://${req.get("host")}`;
// //     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;
 
// //     let signatureRelativePath = null;
 
// //     if (signatureBuffer) {
// //       const allowedTypes = {
// //         "image/jpeg": "jpg",
// //         "image/png": "png"
// //       };
// //       const extension = allowedTypes[signatureMimeType];
// //       if (!extension) {
// //         return res.status(400).json({ message: "Unsupported signature file type" });
// //       }
 
// //       const signatureFolder = path.join("uploads", "signatures");
// //       const signatureFilename = `${momId}-signature.${extension}`;
// //       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);
 
// //       if (!fs.existsSync(signatureDir)) {
// //         fs.mkdirSync(signatureDir, { recursive: true });
// //       }
 
// //       const signaturePath = path.join(signatureDir, signatureFilename);
// //       fs.writeFileSync(signaturePath, signatureBuffer);
 
// //       signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
// //     }
 
// //     const now = new Date();
// //     const formattedDate = now.toISOString().split("T")[0];
// //     const formattedTime = now.toTimeString().split(" ")[0];
 
// //     const momData = {
// //       momId,
// //       projectId,  // ✅ Store projectId in MOM
// //       projectName,
// //       date: formattedDate,
// //       time: formattedTime,
// //       agenda,
// //       meetingMode,
// //       duration,
// //       participants: [],
// //       summary,
// //       notes,
// //       createdBy,
// //       signature: signatureRelativePath || existingMom?.signature,
// //       attachmentUrl,
// //       status
// //     };
 
// //     if (status === "final") {
// //       const pdfBuffer = await generateProjectMomPDF(momData);
// //       const pdfFilename = `${momId}.pdf`;
// //       const pdfDir = path.resolve(__dirname, "../../uploads/moms");
 
// //       if (!fs.existsSync(pdfDir)) {
// //         fs.mkdirSync(pdfDir, { recursive: true });
// //       }
 
// //       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
// //       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
// //     }
 
// //     let savedMom;
// //     if (existingMom) {
// //       // 🔄 Update existing draft
// //       Object.assign(existingMom, momData);
// //       savedMom = await existingMom.save();
// //     } else {
// //       // 🆕 Create new
// //       savedMom = await Mom.create(momData);
// //     }
 
// //     return res.status(200).json({
// //       message: status === "draft" ? "Project MoM saved as draft" : "Project MoM finalized successfully",
// //       mom: savedMom,
// //       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
// //     });
// //   } catch (err) {
// //     console.error("Error:", err);
// //     return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
// //   }
// // };
//  exports.createProjectMOM = async (req, res) => {
//   try {
//     const {
//       projectId,
//       projectName,
//       agenda,
//       meetingMode,
//       duration,
//       summary,
//       notes,
//       createdBy,
//       status // draft / final
//     } = req.body;

//     // ✅ Validate required fields
//     if (!projectId || !projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     // ✅ Handle signature upload
//     const signatureBuffer = req.file?.buffer || null;
//     const signatureMimeType = req.file?.mimetype || "";

//     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();

//     // ✅ Check if there's already a draft for this project
//     let existingMom = await Mom.findOne({ projectId, status: "draft" });

//     let momId;
//     if (existingMom) {
//       momId = existingMom.momId; // Use existing draft momId
//     } else {
//       const momCount = await Mom.countDocuments({ projectId });
//       const sequence = String(momCount + 1).padStart(3, "0");
//       momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
//     }

//     const baseUrl = `${req.protocol}://${req.get("host")}`;
//     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;

//     let signatureRelativePath = null;

//     if (signatureBuffer) {
//       const allowedTypes = {
//         "image/jpeg": "jpg",
//         "image/png": "png"
//       };
//       const extension = allowedTypes[signatureMimeType];
//       if (!extension) {
//         return res.status(400).json({ message: "Unsupported signature file type" });
//       }

//       const signatureFolder = path.join("uploads", "signatures");
//       const signatureFilename = `${momId}-signature.${extension}`;
//       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);

//       if (!fs.existsSync(signatureDir)) {
//         fs.mkdirSync(signatureDir, { recursive: true });
//       }

//       const signaturePath = path.join(signatureDir, signatureFilename);
//       fs.writeFileSync(signaturePath, signatureBuffer);

//       signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
//     }

//     // ✅ Meeting Date (proper Date object)
//     const now = new Date();
//     const formattedDate = now.toISOString().split("T")[0]; // yyyy-mm-dd
//     const formattedTime = now.toTimeString().split(" ")[0]; // hh:mm:ss
//     const meetingDate = new Date(`${formattedDate}T${formattedTime}`); // combine into Date object

//     const momData = {
//       momId,
//       projectId,
//       projectName,
//       date: formattedDate,
//       time: formattedTime,
//       meetingDate, // ✅ store proper Date
//       agenda,
//       meetingMode,
//       duration,
//       participants: [],
//       summary,
//       notes,
//       createdBy,
//       signature: signatureRelativePath || existingMom?.signature,
//       attachmentUrl,
//       status
//     };

//     if (status === "final") {
//       const pdfBuffer = await generateProjectMomPDF(momData);
//       const pdfFilename = `${momId}.pdf`;
//       const pdfDir = path.resolve(__dirname, "../../uploads/moms");

//       if (!fs.existsSync(pdfDir)) {
//         fs.mkdirSync(pdfDir, { recursive: true });
//       }

//       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
//       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
//     }

//     let savedMom;
//     if (existingMom) {
//       Object.assign(existingMom, momData); // 🔄 Update existing draft
//       savedMom = await existingMom.save();
//     } else {
//       savedMom = await Mom.create(momData); // 🆕 Create new
//     }

//     return res.status(200).json({
//       message: status === "draft" ? "Project MoM saved as draft" : "Project MoM finalized successfully",
//       mom: savedMom,
//       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
//     });
//   } catch (err) {
//     console.error("Error:", err);
//     return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
//   }
// };

// exports.viewProjectMOM = async (req, res) => {
//   try {
//     const momId = req.params.momId;
 
//     // 1. Check MOM status in DB
//     const momRecord = await Mom.findOne({ momId });
 
//     if (!momRecord) {
//       return res.status(404).json({ message: "MoM record not found." });
//     }
 
//     // 2. Allow only if status is 'final'
//     if (momRecord.status !== 'final') {
//       return res.status(403).json({ message: "PDF is only available for finalized MoMs." });
//     }
 
//     // 3. Serve PDF if exists
//     const pdfPath = path.resolve(process.cwd(), `uploads/moms/${momId}.pdf`);
//     console.log('Serving PDF from:', pdfPath);
 
//     if (!fs.existsSync(pdfPath)) {
//       return res.status(404).json({ message: "PDF file not found on server." });
//     }
 
//     res.setHeader('Content-Type', 'application/pdf');
//     res.setHeader('Content-Disposition', `inline; filename="${momId}.pdf"`);
//     fs.createReadStream(pdfPath).pipe(res);
//   } catch (error) {
//     console.error('Error viewing MoM PDF:', error);
//     res.status(500).json({ message: "Failed to view MoM PDF", error: error.message });
//   }
// };




// exports.getMomsByProjectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     if (!projectId) {
//       return res.status(400).json({ message: "projectId is required" });
//     }
 
//     // Fetch MOMs linked to this project
//     const moms = await Mom.find({ projectId }).sort({ createdAt: -1 });
 
//     if (!moms || moms.length === 0) {
//       return res.status(404).json({ message: "No MOMs found for this project" });
//     }
 
//     res.status(200).json({
//       message: "MOMs fetched successfully",
//       count: moms.length,
//       data: moms,
//     });
//   } catch (error) {
//     console.error("Error fetching MOMs by projectId:", error);
//     res.status(500).json({ message: "Server error", error: error.message });
//   }
// };
 





// exports.getMomById = async (req, res) => {
//   try {
//     const { momId } = req.params;
 
//     if (!momId) {
//       return res.status(400).json({ message: "momId is required" });
//     }
 
//     const mom = await Mom.findOne({ momId });
 
//     if (!mom) {
//       return res.status(404).json({ message: "MOM not found for given momId" });
//     }
 
//     res.status(200).json({
//       success: true,
//       message: "MOM details fetched successfully",
//       data: mom
//     });
 
//   } catch (error) {
//     console.error("Error fetching MOM:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error while fetching MOM",
//       error: error.message
//     });
//   }
// };
 


const path = require('path');
const Mom = require('../../Model/CalenderModel/ProjectMomModel');
const Project = require('../../Model/ProjectModel/projectModel');
const generateProjectMomPDF = require('../../utils/ProjectpdfGenerator');
const UserToken = require("../../Model/CalenderModel/userTokenModel");
const fs = require('fs');
const moment = require("moment");

// exports.createProjectMOM = async (req, res) => {
//   try {
//     const {
//       projectId,
//       projectName,
//       agenda,
//       meetingMode,
//       duration,
//       summary,
//       notes,
//       createdBy,
//       status,// draft / final
//       attendees
//     } = req.body;
  
//     // Validate required fields
//     if (!projectId || !projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     //  Handle signature upload
//     const signatureBuffer = req.file?.buffer || null;
//     const signatureMimeType = req.file?.mimetype || "";

//     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();

//     // Check if there's already a draft for this project
//     let existingMom = await Mom.findOne({ projectId, status: "draft" });

//     let momId;
//     if (existingMom) {
//       momId = existingMom.momId; // Use existing draft momId
//     } else {
//       const momCount = await Mom.countDocuments({ projectId });
//       const sequence = String(momCount + 1).padStart(3, "0");
//       momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
//     }

//     const baseUrl = `${req.protocol}s://${req.get("host")}`;
//     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;

//     let signatureRelativePath = null;

//     if (signatureBuffer) {
//       const allowedTypes = {
//         "image/jpeg": "jpg",
//         "image/png": "png"
//       };
//       const extension = allowedTypes[signatureMimeType];
//       if (!extension) {
//         return res.status(400).json({ message: "Unsupported signature file type" });
//       }

//       const signatureFolder = path.join("uploads", "signatures");
//       const signatureFilename = `${momId}-signature.${extension}`;
//       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);

//       if (!fs.existsSync(signatureDir)) {
//         fs.mkdirSync(signatureDir, { recursive: true });
//       }

//       const signaturePath = path.join(signatureDir, signatureFilename);
//       fs.writeFileSync(signaturePath, signatureBuffer);

//       signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
//     }

//     //  Meeting Date (proper Date object)
//     const now = new Date();
//     const formattedDate = now.toISOString().split("T")[0]; // yyyy-mm-dd
//     const formattedTime = now.toTimeString().split(" ")[0]; // hh:mm:ss
//     const meetingDate = new Date(`${formattedDate}T${formattedTime}`); // combine into Date object

//     const momData = {
//       momId,
//       projectId,
//       projectName,
//       date: formattedDate,
//       time: formattedTime,
//       meetingDate, //  store proper Date
//       agenda,
//       meetingMode,
//       duration,
//       attendees: attendees || [],    // changed from participants → attendees
//       summary,
//       notes,
//       createdBy,
//       signature: signatureRelativePath || existingMom?.signature,
//       attachmentUrl,
//       status
//     };

//     if (status === "final") {
//       const pdfBuffer = await generateProjectMomPDF(momData);
//       const pdfFilename = `${momId}.pdf`;
//       const pdfDir = path.resolve(__dirname, "../../uploads/moms");

//       if (!fs.existsSync(pdfDir)) {
//         fs.mkdirSync(pdfDir, { recursive: true });
//       }

//       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
//       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
//     }

//     let savedMom;
//     if (existingMom) {
//       Object.assign(existingMom, momData); // Update existing draft
//       savedMom = await existingMom.save();
//     } else {
//       savedMom = await Mom.create(momData); // Create new
//     }

//     return res.status(200).json({
//       message: status === "draft" ? "Project MoM saved as draft" : "Project MoM finalized successfully",
//       mom: savedMom,
//       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
//     });
//   } catch (err) {
//     console.error("Error:", err);
//     return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
//   }
// };

// exports.createProjectMOM = async (req, res) => {
//   try {
//     const {
//       momId: existingMomId, // if present → update
//       projectId,
//       projectName,
//       agenda,
//       meetingMode,
//       duration,
//       summary,
//       notes,
//       createdBy,
//       status, // draft / final
//       attendees
//     } = req.body;

//     // ✅ Validation
//     if (
//       !projectId ||
//       !projectName ||
//       !agenda ||
//       !meetingMode ||
//       !duration ||
//       !summary ||
//       !notes ||
//       !createdBy ||
//       !status
//     ) {
//       return res.status(400).json({ message: "Missing required fields" });
//     }

//     // File upload handling
//     const signatureBuffer = req.file?.buffer || null;
//     const signatureMimeType = req.file?.mimetype || "";

//     const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();

//     let momId = existingMomId;
//     let existingMom = null;

//     if (existingMomId) {
//       // 🔹 Update existing MoM
//       existingMom = await Mom.findOne({ momId: existingMomId });
//       if (!existingMom) {
//         return res.status(404).json({ message: "MoM not found to update" });
//       }
//     } else {
//       // 🔹 Create new MoM → generate momId
//       const momCount = await Mom.countDocuments({ projectId });
//       const sequence = String(momCount + 1).padStart(3, "0");
//       momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
//     }

//     const baseUrl = `${req.protocol}s://${req.get("host")}`;
//     const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;

//     let signatureRelativePath = existingMom?.signature || null;

//     if (signatureBuffer) {
//       const allowedTypes = {
//         "image/jpeg": "jpg",
//         "image/png": "png"
//       };
//       const extension = allowedTypes[signatureMimeType];
//       if (!extension) {
//         return res
//           .status(400)
//           .json({ message: "Unsupported signature file type" });
//       }

//       const signatureFolder = path.join("uploads", "signatures");
//       const signatureFilename = `${momId}-signature.${extension}`;
//       const signatureDir = path.resolve(__dirname, "../../", signatureFolder);

//       if (!fs.existsSync(signatureDir)) {
//         fs.mkdirSync(signatureDir, { recursive: true });
//       }

//       const signaturePath = path.join(signatureDir, signatureFilename);
//       fs.writeFileSync(signaturePath, signatureBuffer);

//       signatureRelativePath = path.posix.join(
//         "uploads",
//         "signatures",
//         signatureFilename
//       );
//     }

//     // Meeting date/time
//     const now = new Date();
//     const formattedDate = now.toISOString().split("T")[0];
//     const formattedTime = now.toTimeString().split(" ")[0];
//     const meetingDate = new Date(`${formattedDate}T${formattedTime}`);

//     const momData = {
//       momId,
//       projectId,
//       projectName,
//       date: formattedDate,
//       time: formattedTime,
//       meetingDate,
//       agenda,
//       meetingMode,
//       duration,
//       attendees: attendees || [],
//       summary,
//       notes,
//       createdBy,
//       signature: signatureRelativePath,
//       attachmentUrl,
//       status
//     };

//     // ✅ Generate PDF only for final
//     if (status === "final") {
//       const pdfBuffer = await generateProjectMomPDF(momData);
//       const pdfFilename = `${momId}.pdf`;
//       const pdfDir = path.resolve(__dirname, "../../uploads/moms");

//       if (!fs.existsSync(pdfDir)) {
//         fs.mkdirSync(pdfDir, { recursive: true });
//       }

//       fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
//       momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
//     }

//     let savedMom;
//     if (existingMom) {
//       // 🔹 Update
//       savedMom = await Mom.findOneAndUpdate({ momId }, momData, {
//         new: true
//       });
//     } else {
//       // 🔹 Create new
//       savedMom = await Mom.create(momData);
//     }

//     return res.status(200).json({
//       message: existingMom
//         ? "Project MoM updated successfully"
//         : "Project MoM created successfully",
//       mom: savedMom,
//       ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
//     });
//   } catch (err) {
//     console.error("Error:", err);
//     return res.status(500).json({
//       message: "Failed to create/update Project MOM",
//       error: err.message
//     });
//   }
// };



exports.createProjectMOM = async (req, res) => {
  try {
    const {
      projectId,
      projectName,
      agenda,
      meetingMode,
      duration,
      summary,
      notes,
      createdBy,
      status, // draft / final
      attendees
    } = req.body;
 
    //  Validate required fields
    if (!projectId || !projectName || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
      return res.status(400).json({ message: "Missing required fields" });
    }
 
    //  Handle signature upload
    const signatureBuffer = req.file?.buffer || null;
    const signatureMimeType = req.file?.mimetype || "";
 
    const projectKey = projectName.replace(/\s+/g, "_").toUpperCase();
 
    //  Check if there's already a draft for this project
    let existingMom = await Mom.findOne({ projectId, status: "draft", isDeleted: false });
 
    let momId;
    if (existingMom) {
      momId = existingMom.momId; // Use existing draft momId
    } else {
      const momCount = await Mom.countDocuments({ projectId, isDeleted: false });
      const sequence = String(momCount + 1).padStart(3, "0");
      momId = `AAS-IT-MOM-${projectKey}-${sequence}`;
    }
 
    const baseUrl = `${req.protocol}://${req.get("host")}`;
    const attachmentUrl = `${baseUrl}/api/projectmom/view/${momId}`;
 
    let signatureRelativePath = null;
 
    if (signatureBuffer) {
      const allowedTypes = {
        "image/jpeg": "jpg",
        "image/png": "png"
      };
      const extension = allowedTypes[signatureMimeType];
      if (!extension) {
        return res.status(400).json({ message: "Unsupported signature file type" });
      }
 
      const signatureFolder = path.join("uploads", "signatures");
      const signatureFilename = `${momId}-signature.${extension}`;
      const signatureDir = path.resolve(__dirname, "../../", signatureFolder);
 
      if (!fs.existsSync(signatureDir)) {
        fs.mkdirSync(signatureDir, { recursive: true });
      }
 
      const signaturePath = path.join(signatureDir, signatureFilename);
      fs.writeFileSync(signaturePath, signatureBuffer);
 
      signatureRelativePath = path.posix.join("uploads", "signatures", signatureFilename);
    }
 
    //  Meeting Date (proper Date object)
    const now = new Date();
    const formattedDate = now.toISOString().split("T")[0]; // yyyy-mm-dd
    const formattedTime = now.toTimeString().split(" ")[0]; // hh:mm:ss
    const meetingDate = new Date(`${formattedDate}T${formattedTime}`); // combine into Date object
 
    const momData = {
      momId,
      projectId,
      projectName,
      date: formattedDate,
      time: formattedTime,
      meetingDate, //  store proper Date
      agenda,
      meetingMode,
      duration,
      attendees: attendees || [],
      summary,
      notes,
      createdBy,
      signature: signatureRelativePath || existingMom?.signature,
      attachmentUrl,
      status,
      isDeleted: false //  ensure newly created/updated MOM is always active
    };
 
    if (status === "final") {
      const pdfBuffer = await generateProjectMomPDF(momData);
      const pdfFilename = `${momId}.pdf`;
      const pdfDir = path.resolve(__dirname, "../../uploads/moms");
 
      if (!fs.existsSync(pdfDir)) {
        fs.mkdirSync(pdfDir, { recursive: true });
      }
 
      fs.writeFileSync(path.join(pdfDir, pdfFilename), pdfBuffer);
      momData.pdfUrl = `${baseUrl}/api/projectmom/view/${momId}`;
    }
 
    let savedMom;
    if (existingMom) {
      Object.assign(existingMom, momData); // Update existing draft
      savedMom = await existingMom.save();
    } else {
      savedMom = await Mom.create(momData); //  Create new
    }
 
    return res.status(200).json({
      message: status === "draft" ? "Project MoM saved as draft" : "Project MoM finalized successfully",
      mom: savedMom,
      ...(savedMom.pdfUrl && { pdfUrl: savedMom.pdfUrl })
    });
  } catch (err) {
    console.error("Error:", err);
    return res.status(500).json({ message: "Failed to create Project MOM", error: err.message });
  }
};








































exports.viewProjectMOM = async (req, res) => {
  try {
    const momId = req.params.momId;

    const momRecord = await Mom.findOne({ momId });
    if (!momRecord) {
      return res.status(404).json({ message: "MoM record not found." });
    }

    if (momRecord.status !== 'final') {
      return res.status(403).json({ message: "PDF is only available for finalized MoMs." });
    }

    const pdfPath = path.resolve(process.cwd(), `uploads/moms/${momId}.pdf`);
    console.log('Serving PDF from:', pdfPath);

    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: "PDF file not found on server." });
    }

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${momId}.pdf"`);
    fs.createReadStream(pdfPath).pipe(res);
  } catch (error) {
    console.error('Error viewing MoM PDF:', error);
    res.status(500).json({ message: "Failed to view MoM PDF", error: error.message });
  }
};

exports.getMomsByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;

    if (!projectId) {
      return res.status(400).json({ message: "projectId is required" });
    }

    const moms = await Mom.find({ projectId }).sort({ createdAt: -1 });

    if (!moms || moms.length === 0) {
      return res.status(404).json({ message: "No MOMs found for this project" });
    }

    res.status(200).json({
      message: "MOMs fetched successfully",
      count: moms.length,
      data: moms,
    });
  } catch (error) {
    console.error("Error fetching MOMs by projectId:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

exports.getMomById = async (req, res) => {
  try {
    const { momId } = req.params;

    if (!momId) {
      return res.status(400).json({ message: "momId is required" });
    }

    const mom = await Mom.findOne({ momId });

    if (!mom) {
      return res.status(404).json({ message: "MOM not found for given momId" });
    }

    res.status(200).json({
      success: true,
      message: "MOM details fetched successfully",
      data: mom
    });

  } catch (error) {
    console.error("Error fetching MOM:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching MOM",
      error: error.message
    });
  }
};

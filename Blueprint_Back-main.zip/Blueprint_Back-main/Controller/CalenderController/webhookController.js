// const PaymentStatus = require("../../Model/CalenderModel/paymentModel");

// exports.handleWebhook = async (req, res) => {
//   const event = req.body;

//   if (event.event === "payment_link.paid") {
//     const payment = event.payload.payment.entity;
//     const contactId = payment.notes.contactId;

//     await PaymentStatus.findOneAndUpdate(
//       { contactId },
//       { status: "paid", paymentId: payment.id }
//     );
//   }

//   res.status(200).json({ received: true });
// };



const crypto = require("crypto");
const PaymentStatus = require("../../Model/CalenderModel/paymentModel");

exports.handleWebhook = async (req, res) => {
  try {
    const webhookSecret = "chinmayakumardas";

    const razorpaySignature = req.headers["x-razorpay-signature"];
    const payload = JSON.stringify(req.body);

    const expectedSignature = crypto
      .createHmac("sha256", webhookSecret)
      .update(payload)
      .digest("hex");

    if (razorpaySignature !== expectedSignature) {
      console.log(" Invalid signature");
      return res.status(400).send("Invalid signature");
    }

    const event = req.body.event;
    const entity = req.body.payload?.payment?.entity;

    if (event === "payment.captured" && entity) {
      const paymentId = entity.id;

      const updated = await PaymentStatus.findOneAndUpdate(
        { paymentId },
        { $set: { status: "paid", statusCode: "captured" } },
        { new: true }
      );

      if (!updated) {
        console.warn(" Payment record not found for:", paymentId);
      } else {
        console.log(" Payment status updated for:", paymentId);
      }
    }

    res.status(200).json({ success: true });
  } catch (error) {
    console.error(" Webhook Error:", error);
    res.status(500).json({ error: "Server error in webhook" });
  }
};

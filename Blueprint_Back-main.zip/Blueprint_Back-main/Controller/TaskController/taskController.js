// const Task = require('../../Model/TaskModel/Task');
// const Bug = require('../../Model/BugModel/Bug');
// const Notification = require('../../Model/NotificationModel/notificationModel');
// const Team=require('../../Model/TeamModel/Team')
 
 
// exports.assignTask = async (req, res) => {
//   try {
//     const {
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     } = req.body;
 
//     if (!title || !assignedTo || !assignedBy || !projectId) {
//       return res.status(400).json({
//         message: 'Title, assignedTo, assignedBy, and projectId are required.'
//       });
//     }
 
//     // Create the task with a custom ID generator
//     const task = await Task.createTaskWithId({
//       title,
//       description,
//       assignedTo,
//       assignedBy,
//       priority,
//       deadline,
//       projectId,
//       projectName,
//       memberId
//     });
 
//     // Create a notification for the assignee
//     const notification = new Notification({
//       recipientId: assignedTo.toString(),
//       message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
//       link: `/tasks/${task.task_id}` // Adjust path format if necessary
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Task assigned successfully',
//       task
//     });
//   } catch (err) {
//     res.status(500).json({
//       message: 'Internal server error',
//       error: err.message
//     });
//   }
// };
 
 
// exports.getAllTasks = async (req, res) => {
//   try {
//     const todayStart = new Date();
//     todayStart.setHours(0, 0, 0, 0);
 
//     const todayEnd = new Date();
//     todayEnd.setHours(23, 59, 59, 999);
 
//     // Fetch all tasks (not just today’s)
//     const tasks = await Task.find({ isDeleted: false }).sort({ createdAt: -1 }).lean();
 
//     // Count tasks with today's deadline
//     const todayDeadlineTasksCount = tasks.filter(task =>
//       task.deadline &&
//       new Date(task.deadline) >= todayStart &&
//       new Date(task.deadline) <= todayEnd
//     ).length;
 
//     // Get all teams and build a memberId -> memberName map
//     const teams = await Team.find({ isDeleted: false }).lean();
//     const memberMap = {};
//     for (const team of teams) {
//       for (const member of team.teamMembers) {
//         memberMap[member.memberId] = member.memberName;
//       }
//     }
 
//     // Add assignedToName to each task
//     const tasksWithMemberNames = tasks.map(task => ({
//       ...task,
//       assignedToName: memberMap[task.assignedTo] || 'Unknown'
//     }));
 
//     res.status(200).json({
//       totalTasks: tasks.length,
//       todayDeadlineTasks: todayDeadlineTasksCount,
//       tasks: tasksWithMemberNames
//     });
 
//   } catch (err) {
//     console.error('Error fetching tasks:', err);
//     res.status(500).json({ message: 'Failed to fetch tasks', error: err.message });
//   }
// };
//  // Get all tasks for a specific memberId
// // exports.getTasksByMemberId = async (req, res) => {
// //   const { memberId } = req.params;
 
// //   try {
// //     if (!memberId) {
// //       return res.status(400).json({ message: "memberId is required" });
// //     }
 
// //     const tasks = await Task.find({ 
// //       memberId, 
// //       isDeleted: false 
// //     }).populate('bugIds'); // Optional: populate bugs if needed
 
// //     if (!tasks.length) {
// //       return res.status(404).json({ message: "No tasks found for this member" });
// //     }
 
// //     res.status(200).json({ success: true, data: tasks });
 
// //   } catch (error) {
// //     console.error("Error fetching tasks by memberId:", error);
// //     res.status(500).json({ success: false, message: "Server Error", error: error.message });
// //   }
// // };
// exports.getTasksByMemberId = async (req, res) => {
//   const { memberId } = req.params;

//   try {
//     if (!memberId) {
//       return res.status(400).json({ message: "memberId is required" });
//     }

//     // Step 1: Fetch tasks where assignedTo = memberId
//     const tasks = await Task.find({
//       assignedTo: memberId,
//       isDeleted: false
//     }).populate('bugIds').lean(); // lean returns plain JS objects

//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for this member" });
//     }

//     // Step 2: Fetch all teams
//     const teams = await Team.find({ isDeleted: false }).lean();

//     // Step 3: Build memberId -> { name, role, email } map
//     const memberMap = {};
//     teams.forEach(team => {
//       team.teamMembers.forEach(member => {
//         memberMap[member.memberId] = {
//           name: member.memberName,
//           role: member.role,
//           email: member.email
//         };
//       });
//     });

//     // Step 4: Enrich each task with assignedToName, assignedToRole, assignedToEmail
//     const enrichedTasks = tasks.map(task => {
//       const memberInfo = memberMap[task.assignedTo] || {};
//       return {
//         ...task,
//         assignedToName: memberInfo.name || 'Unknown',
//         assignedToRole: memberInfo.role || 'Unknown',
//         assignedToEmail: memberInfo.email || 'Unknown'
//       };
//     });

//     // Step 5: Send response
//     res.status(200).json({
//       success: true,
//       data: enrichedTasks
//     });

//   } catch (error) {
//     console.error("Error fetching tasks by memberId:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server Error",
//       error: error.message
//     });
//   }
// };








// // Get Single Task by task_id
// // exports.getTaskById = async (req, res) => {
// //   try {
// //     const task = await Task.findOne({ task_id: req.params.task_id });
 
// //     if (!task) {
// //       return res.status(404).json({ message: 'Task not found' });
// //     }
 
// //     res.status(200).json({ task });
 
// //   } catch (err) {
// //     res.status(500).json({ message: 'Failed to get task', error: err.message });
// //   }
// // };
 
// exports.getTaskById = async (req, res) => {

//   try {

//     const task = await Task.findOne({ task_id: req.params.task_id });
 
//     if (!task) {

//       return res.status(404).json({ message: 'Task not found' });

//     }
 
//     // Fetch teams for the project

//     const teams = await Team.find({ projectId: task.projectId, isDeleted: false });

//     const allMembers = teams.flatMap(team => team.teamMembers);

//     const allTeamLeads = teams.map(team => ({

//       memberId: team.teamLeadId,

//       memberName: team.teamLeadName,

//       role: 'Team Lead',

//       email: '', // Optional: Store teamLeadEmail in your Team schema if available

//       _id: null

//     }));
 
//     const everyone = [...allMembers, ...allTeamLeads];
 
//     // Find assignedTo member

//     const assignedToMember = everyone.find(member => member.memberId === task.assignedTo);
 
//     // Find assignedBy member (match by name or ID)

//     const assignedByMember = everyone.find(

//       member => member.memberId === task.assignedBy || member.memberName === task.assignedBy

//     );
 
//     const enrichedTask = {

//       ...task.toObject(),

//       assignedToDetails: assignedToMember

//         ? {

//             _id: assignedToMember._id,

//             memberId: assignedToMember.memberId,

//             memberName: assignedToMember.memberName,

//             email: assignedToMember.email,

//             role: assignedToMember.role

//           }

//         : null,

//       assignedByDetails: assignedByMember

//         ? {

//             _id: assignedByMember._id,

//             memberId: assignedByMember.memberId,

//             memberName: assignedByMember.memberName,

//             email: assignedByMember.email,

//             role: assignedByMember.role

//           }

//         : null

//     };
 
//     res.status(200).json({ task: enrichedTask });
 
//   } catch (err) {

//     console.error('Error in getTaskById:', err);

//     res.status(500).json({ message: 'Failed to get task', error: err.message });

//   }

// };
 
//  exports.updateTask = async (req, res) => {

//   try {

//     const taskId = req.params.task_id;

//     // Find the existing task first

//     const existingTask = await Task.findOne({ task_id: taskId });

//     if (!existingTask) {

//       return res.status(404).json({ message: 'Task not found' });

//     }
 
//     // Update the task

//     const updatedTask = await Task.findOneAndUpdate(

//       { task_id: taskId },

//       req.body,

//       { new: true }

//     );
 
//     // Create a notification message based on what was updated

//     let message = `Task "${updatedTask.title}" has been updated.`;

//     // Check if reassigned

//     if (req.body.assignedTo && req.body.assignedTo !== existingTask.assignedTo.toString()) {

//       message = `You have been assigned a new task: "${updatedTask.title}".`;

//       const reassignedNotification = new Notification({

//         recipientId: req.body.assignedTo.toString(),

//         message,

//         link: `/tasks/${updatedTask.task_id}`

//       });

//       await reassignedNotification.save();

//     } else {

//       // Generic update notification for the current assignee

//       const updateNotification = new Notification({

//         recipientId: updatedTask.assignedTo.toString(),

//         message,

//         link: `/tasks/${updatedTask.task_id}`

//       });

//       await updateNotification.save();

//     }
 
//     res.status(200).json({

//       message: 'Task updated successfully',

//       task: updatedTask

//     });
 
//   } catch (err) {

//     res.status(500).json({

//       message: 'Failed to update task',

//       error: err.message

//     });

//   }

// };
 
// // Delete Task permanenly
// exports.deleteTaskPermanent= async (req, res) => {
//   try {
//     const deletedTask = await Task.findOneAndDelete({ task_id: req.params.task_id });
 
//     if (!deletedTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     res.status(200).json({ message: 'Task deleted successfully' });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to delete task', error: err.message });
//   }
// };
 
 
// // Soft Delete Task
// exports.deleteTask = async (req, res) => {
//   try {
//     const deletedTask = await Task.findOneAndUpdate(
//       { task_id: req.params.task_id },
//       { isDeleted: true },
//       { new: true }
//     );
 
//     if (!deletedTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     res.status(200).json({ message: 'Task soft-deleted successfully' });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to delete task', error: err.message });
//   }
// };
 
 
// // Update Task Status
// exports.updateTaskStatus = async (req, res) => {
//   const { task_id } = req.params;
//   const { status, feedback } = req.body;
 
//   try {
//     const task = await Task.findOne({ task_id, isDeleted: false });
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     // If changing to 'Completed'
//    if (status === 'Completed') {
//   const now = new Date();
//   const todayStr = now.toISOString().split('T')[0];
//   const deadlineStr = task.deadline?.toISOString().split('T')[0];
 
//   const isLate = deadlineStr && todayStr > deadlineStr;
 
//   if (isLate && (!feedback || feedback.trim() === '')) {
//     return res.status(400).json({
//       message: 'Task is completed after the deadline. Feedback is required for the delay.'
//     });
//   }
 
//   task.completedAt = now;
//   task.isLate = isLate;
//   task.completionFeedback = isLate ? feedback : undefined;
// }
 
//     task.status = status;
//     await task.save();
 
//     res.json({ message: 'Task status updated successfully', task });
//   } catch (error) {
//     res.status(500).json({ message: 'Server error', error: error.message });
//   }
// };
 
 
// // Get tasks by assignee
// exports.getTasksByAssignee = async (req, res) => {
//   try {
//     const { assignedTo } = req.body;
//     const tasks = await Task.find({ assignedTo }).sort({ dueDate: 1 });
//     res.json(tasks);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };
 
 
 

 
// exports.reviewTask = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { reviewedBy, reviewStatus } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     task.reviewedBy = reviewedBy;
//     task.reviewStatus = reviewStatus;
 
//     if (reviewStatus === 'Accepted') {
//       task.status = 'Completed';
//       task.completedAt = new Date();
//     }
 
//     await task.save();
 
//     // Send notification to the task assignee
//     const notificationMessage = `Your task "${task.title}" has been reviewed and marked as "${reviewStatus}".`;
 
//     const notification = new Notification({
//       recipientId: task.assignedTo.toString(), // Make sure this is a string ID
//       message: notificationMessage,
//       link: `/tasks/${task.task_id}`, // Adjust the link format as needed
//     });
 
//     await notification.save();
 
//     res.status(200).json({ message: 'Task reviewed successfully', task });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
// // Get all tasks by projectiD AND projectName
// exports. getAllTask = async (req, res) => {
//   try {
//     const tasks = await Task.find().populate('projectId', 'projectName');
//     res.status(200).json(tasks);
//   } catch (error) {
//     res.status(500).json({ message: 'Error retrieving tasks', error });
//   }
// };
 
 
 
 
 

//  exports.getTasksByDeadline = async (req, res) => {
//   try {
//     // Set start of today
//     const startOfToday = new Date();
//     startOfToday.setHours(0, 0, 0, 0); // 00:00:00
 
//     // Set end of 7th day from today
//     const endOfNext7Days = new Date();
//     endOfNext7Days.setDate(startOfToday.getDate() + 7);
//     endOfNext7Days.setHours(23, 59, 59, 999); // 23:59:59
 
//     const tasks = await Task.find({
//       deadline: {
//         $gte: startOfToday,
//         $lte: endOfNext7Days
//       },
//       isDeleted: false
//     });
 
//     res.status(200).json({
//       success: true,
//       count: tasks.length,
//       data: tasks
//     });
//   } catch (error) {
//     console.error('Error fetching upcoming deadline tasks:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Internal Server Error'
//     });
//   }
// };
// // Link a bug to a task
// exports.linkBugToTask = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { bug_id } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) return res.status(404).json({ message: 'Bug not found' });
 
//     // prevent duplicate
//     if (!task.bugIds.includes(bug_id)) {
//       task.bugIds.push(bug_id);
//     }
 
//     task.status = 'In Progress';
//     task.reviewStatus = 'Rejected';
//     await task.save();
 
//     res.status(200).json({ message: 'Bug linked to task successfully', task });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
 
 
// // Get project task summary
// exports.getProjectTaskSummary = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     const now = new Date();
//     const threeDaysLater = new Date();
//     threeDaysLater.setDate(now.getDate() + 3);
 
//     const totalTasks = await Task.countDocuments({ projectId });
//     const completedTasks = await Task.countDocuments({ projectId, status: 'Completed' });
//     const inProgressTasks = await Task.countDocuments({ projectId, status: 'In Progress' });
//     const pendingTasks = await Task.countDocuments({ projectId, status: 'Pending' });
 
//     const tasksExpiringSoon = await Task.countDocuments({
//       projectId,
//       deadline: { $gte: now, $lte: threeDaysLater }
//     });
 
//     res.status(200).json({
//       projectId,
//       totalTasks,
//       completedTasks,
//       inProgressTasks,
//       pendingTasks,
//       tasksExpiringSoon
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 
 
 
// // exports.getTasksByprojectId = async (req, res) => {
// //   try {
// //     const { projectId } = req.params;
// //     const tasks = await Task.find({ projectId }).sort({ dueDate: 1 });
// //     res.json(tasks);
// //   } catch (err) {
// //     res.status(500).json({ error: err.message });
// //   }
// // };

//  exports.getTasksByprojectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
 
//     // 1. Fetch tasks for the project
//     const tasks = await Task.find({ projectId }).sort({ dueDate: 1 });
 
//     // 2. Fetch team by projectId
//     const team = await Team.findOne({ projectId, isDeleted: false });
//     if (!team) {
//       return res.status(404).json({ message: 'Team not found for this project' });
//     }
 
//     // 3. Map over tasks and attach member details from team
//     const enrichedTasks = tasks.map(task => {
//       const assignedMember = team.teamMembers.find(member => member.memberId === task.assignedTo);
 
//       return {
//         ...task.toObject(),
//         assignedToDetails: assignedMember ? {
//           _id: assignedMember._id,
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role
//         } : null
//       };
//     });
 
//     res.json(enrichedTasks);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: err.message });
//   }
// };
 
 
 
// exports.getTaskCounts = async (req, res) => {
//     try {
//         // Get today's date boundaries
//         const today = new Date();
//         today.setHours(0, 0, 0, 0);
//         const tomorrow = new Date(today);
//         tomorrow.setDate(tomorrow.getDate() + 1);
 
//         // Count all tasks (excluding deleted ones)
//         const totalTasks = await Task.countDocuments({ isDeleted: false });
 
//         // Count tasks with deadline today
//         const todayTasks = await Task.countDocuments({
//             isDeleted: false,
//             deadline: {
//                 $gte: today,
//                 $lt: tomorrow
//             }
//         });
 
//         res.status(200).json({
//             success: true,
//             data: {
//                 totalTasks,
//                 todayDeadlineTasks: todayTasks
//             }
//         });
//     } catch (error) {
//         res.status(500).json({
//             success: false,
//             message: 'Error fetching task counts',
//             error: error.message
//         });
//     }
// };

// exports.updateTaskStatusById = async (req, res) => {
//   try {
//     const { task_id } = req.params;
//     const { status } = req.body;
 
//     // Validate status
//     const validStatuses = ['Pending', 'In Progress', 'Completed'];
//     if (!validStatuses.includes(status)) {
//       return res.status(400).json({
//         success: false,
//         message: 'Invalid status. Must be Pending, In Progress, or Completed.',
//       });
//     }
 
//     const task = await Task.findOne({ task_id });
 
//     if (!task) {
//       return res.status(404).json({
//         success: false,
//         message: 'Task not found',
//       });
//     }
 
//     task.status = status;
 
//     // If task is marked completed, set completedAt
//     if (status === 'Completed' && !task.completedAt) {
//       task.completedAt = new Date();
 
//       if (task.deadline && new Date() > new Date(task.deadline)) {
//         task.isLate = true;
//       }
//     }
 
//     await task.save();
 
//     res.status(200).json({
//       success: true,
//       message: 'Task status updated successfully',
//       task,
//     });
//   } catch (err) {
//     console.error('Error updating task status:', err);
//     res.status(500).json({
//       success: false,
//       message: 'Internal server error',
//     });
//   }
// };
 const Task = require('../../Model/TaskModel/Task');
const Bug = require('../../Model/BugModel/Bug');
const Notification = require('../../Model/NotificationModel/notificationModel');
const Team=require('../../Model/TeamModel/Team')
const pushTaskHistory=require("../../utils/pushTaskHistory")
 const ExcelJS = require("exceljs");
 
exports.assignTask = async (req, res) => {
  try {
    const {
      title,
      description,
      assignedTo,
      assignedBy,
      priority,
      deadline,
      projectId,
      projectName,
      memberId
    } = req.body;
 
    if (!title || !assignedTo || !assignedBy || !projectId) {
      return res.status(400).json({
        message: 'Title, assignedTo, assignedBy, and projectId are required.'
      });
    }
 
    // Create the task with a custom ID generator
    const task = await Task.createTaskWithId({
      title,
      description,
      assignedTo,
      assignedBy,
      priority,
      deadline,
      projectId,
      projectName,
      memberId
    });
 
    // Create a notification for the assignee
    const notification = new Notification({
      recipientId: assignedTo.toString(),
      message: `You have been assigned a new task: "${title}" in project "${projectName}".`,
      link: `/tasks/${task.task_id}` // Adjust path format if necessary
    });
 
    await notification.save();
 
    res.status(201).json({
      message: 'Task assigned successfully',
      task
    });
  } catch (err) {
    res.status(500).json({
      message: 'Internal server error',
      error: err.message
    });
  }
};
 
 
exports.getAllTasks = async (req, res) => {
  try {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
 
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);
 
    // Fetch all tasks (not just today’s)
    const tasks = await Task.find({ isDeleted: false }).sort({ createdAt: -1 }).lean();
 
    // Count tasks with today's deadline
    const todayDeadlineTasksCount = tasks.filter(task =>
      task.deadline &&
      new Date(task.deadline) >= todayStart &&
      new Date(task.deadline) <= todayEnd
    ).length;
 
    // Get all teams and build a memberId -> memberName map
    const teams = await Team.find({ isDeleted: false }).lean();
    const memberMap = {};
    for (const team of teams) {
      for (const member of team.teamMembers) {
        memberMap[member.memberId] = member.memberName;
      }
    }
 
    // Add assignedToName to each task
    const tasksWithMemberNames = tasks.map(task => ({
      ...task,
      assignedToName: memberMap[task.assignedTo] || 'Unknown'
    }));
 
    res.status(200).json({
      totalTasks: tasks.length,
      todayDeadlineTasks: todayDeadlineTasksCount,
      tasks: tasksWithMemberNames
    });
 
  } catch (err) {
    console.error('Error fetching tasks:', err);
    res.status(500).json({ message: 'Failed to fetch tasks', error: err.message });
  }
};
 // Get all tasks for a specific memberId
// exports.getTasksByMemberId = async (req, res) => {
//   const { memberId } = req.params;
 
//   try {
//     if (!memberId) {
//       return res.status(400).json({ message: "memberId is required" });
//     }
 
//     const tasks = await Task.find({
//       memberId,
//       isDeleted: false
//     }).populate('bugIds'); // Optional: populate bugs if needed
 
//     if (!tasks.length) {
//       return res.status(404).json({ message: "No tasks found for this member" });
//     }
 
//     res.status(200).json({ success: true, data: tasks });
 
//   } catch (error) {
//     console.error("Error fetching tasks by memberId:", error);
//     res.status(500).json({ success: false, message: "Server Error", error: error.message });
//   }
// };
exports.getTasksByMemberId = async (req, res) => {
  const { memberId } = req.params;
 
  try {
    if (!memberId) {
      return res.status(400).json({ message: "memberId is required" });
    }
 
    // Step 1: Fetch tasks where assignedTo = memberId
    const tasks = await Task.find({
      assignedTo: memberId,
      isDeleted: false
    }).populate('bugIds').lean(); // lean returns plain JS objects
 
    if (!tasks.length) {
      return res.status(404).json({ message: "No tasks found for this member" });
    }
 
    // Step 2: Fetch all teams
    const teams = await Team.find({ isDeleted: false }).lean();
 
    // Step 3: Build memberId -> { name, role, email } map
    const memberMap = {};
    teams.forEach(team => {
      team.teamMembers.forEach(member => {
        memberMap[member.memberId] = {
          name: member.memberName,
          role: member.role,
          email: member.email
        };
      });
    });
 
    // Step 4: Enrich each task with assignedToName, assignedToRole, assignedToEmail
    const enrichedTasks = tasks.map(task => {
      const memberInfo = memberMap[task.assignedTo] || {};
      return {
        ...task,
        assignedToName: memberInfo.name || 'Unknown',
        assignedToRole: memberInfo.role || 'Unknown',
        assignedToEmail: memberInfo.email || 'Unknown'
      };
    });
 
    // Step 5: Send response
    res.status(200).json({
      success: true,
      data: enrichedTasks
    });
 
  } catch (error) {
    console.error("Error fetching tasks by memberId:", error);
    res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message
    });
  }
};
 
 
 
 
 
 
 
 
// Get Single Task by task_id
// exports.getTaskById = async (req, res) => {
//   try {
//     const task = await Task.findOne({ task_id: req.params.task_id ,isDeleted: false }).populate('bugIds');
 
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     res.status(200).json({ task });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Failed to get task', error: err.message });
//   }
// };
exports.getTaskById = async (req, res) => {
  try {
    // 1. Find the task by task_id
    const task = await Task.findOne({ task_id: req.params.task_id, isDeleted: false });
 
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    // 2. Get projectId from task and fetch team(s)
    const projectId = task.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });
 
    // 3. Flatten all team members
    const allMembers = teams.flatMap(team => team.teamMembers);
 
    // 4. Find assignedTo member
    const assignedMember = allMembers.find(member => member.memberId === task.assignedTo);
 
    // 5. Add assignedToDetails if found
    const assignedToDetails = assignedMember ? {
      _id: assignedMember._id,
      memberId: assignedMember.memberId,
      memberName: assignedMember.memberName,
      email: assignedMember.email,
      role: assignedMember.role
    } : null;
 
    // 6. Prepare final enriched task
    const enrichedTask = {
      ...task.toObject(),
      assignedToDetails
    };
 
    res.status(200).json({ task: enrichedTask });
 
  } catch (err) {
    console.error('Error in getTaskById:', err);
    res.status(500).json({ message: 'Failed to get task', error: err.message });
  }
};
 exports.updateTask = async (req, res) => {
  try {
    const taskId = req.params.task_id;
 
    // Find the existing task first
    const existingTask = await Task.findOne({ task_id: taskId });
 
    if (!existingTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    // If status is updated to "Completed"
    if (req.body.status && req.body.status === 'Completed') {
      const currentTime = new Date();
 
      // Check if task is completed after deadline
      if (existingTask.deadline && currentTime > new Date(existingTask.deadline)) {
        // It's late
        if (!req.body.delayReason || req.body.delayReason.trim() === '') {
          return res.status(400).json({
            message: 'Task is completed after the deadline. Please provide a delayReason.'
          });
        }
 
        req.body.isLate = true;
        req.body.completedAt = currentTime;
      } else {
        // Not late
        req.body.isLate = false;
        req.body.delayReason = ''; // Clear old reason if any
        req.body.completedAt = currentTime;
      }
    }
 
    // Update the task
    const updatedTask = await Task.findOneAndUpdate(
      { task_id: taskId },
      req.body,
      { new: true }
    );
 
    // Create a notification message
    let message = `Task "${updatedTask.title}" has been updated.`;
 
    if (
      req.body.assignedTo &&
      req.body.assignedTo !== existingTask.assignedTo?.toString()
    ) {
      message = `You have been assigned a new task: "${updatedTask.title}".`;
 
      const reassignedNotification = new Notification({
        recipientId: req.body.assignedTo.toString(),
        message,
        link: `/tasks/${updatedTask.task_id}`,
      });
 
      await reassignedNotification.save();
    } else {
      const updateNotification = new Notification({
        recipientId: updatedTask.assignedTo?.toString(),
        message,
        link: `/tasks/${updatedTask.task_id}`,
      });
 
      await updateNotification.save();
    }
 
    res.status(200).json({
      message: 'Task updated successfully',
      task: updatedTask,
    });
  } catch (err) {
    res.status(500).json({
      message: 'Failed to update task',
      error: err.message,
    });
  }
};
//  exports.updateTask = async (req, res) => {
//   try {
//     const taskId = req.params.task_id;
 
//     // Find the existing task first
//     const existingTask = await Task.findOne({ task_id: taskId });
 
//     if (!existingTask) {
//       return res.status(404).json({ message: 'Task not found' });
//     }
 
//     // ✅ If status is updated to "Completed", set reviewStatus to "InReview"
//     if (req.body.status && req.body.status === 'Completed') {
//       req.body.reviewStatus = 'InReview';
//     }
 
//     // Update the task
//     const updatedTask = await Task.findOneAndUpdate(
//       { task_id: taskId },
//       req.body,
//       { new: true }
//     );
 
//     // Create a notification message
//     let message = `Task "${updatedTask.title}" has been updated.`;
 
//     if (
//       req.body.assignedTo &&
//       req.body.assignedTo !== existingTask.assignedTo.toString()
//     ) {
//       message = `You have been assigned a new task: "${updatedTask.title}".`;
 
//       const reassignedNotification = new Notification({
//         recipientId: req.body.assignedTo.toString(),
//         message,
//         link: `/tasks/${updatedTask.task_id}`,
//       });
 
//       await reassignedNotification.save();
//     } else {
//       const updateNotification = new Notification({
//         recipientId: updatedTask.assignedTo.toString(),
//         message,
//         link: `/tasks/${updatedTask.task_id}`,
//       });
 
//       await updateNotification.save();
//     }
 
//     res.status(200).json({
//       message: 'Task updated successfully',
//       task: updatedTask,
//     });
//   } catch (err) {
//     res.status(500).json({
//       message: 'Failed to update task',
//       error: err.message,
//     });
//   }
// };
 
//  exports.updateTask = async (req, res) => {
 
//   try {
 
//     const taskId = req.params.task_id;
 
//     // Find the existing task first
 
//     const existingTask = await Task.findOne({ task_id: taskId });
 
//     if (!existingTask) {
 
//       return res.status(404).json({ message: 'Task not found' });
 
//     }
 
//     // Update the task
 
//     const updatedTask = await Task.findOneAndUpdate(
 
//       { task_id: taskId },
 
//       req.body,
 
//       { new: true }
 
//     );
 
//     // Create a notification message based on what was updated
 
//     let message = `Task "${updatedTask.title}" has been updated.`;
 
//     // Check if reassigned
 
//     if (req.body.assignedTo && req.body.assignedTo !== existingTask.assignedTo.toString()) {
 
//       message = `You have been assigned a new task: "${updatedTask.title}".`;
 
//       const reassignedNotification = new Notification({
 
//         recipientId: req.body.assignedTo.toString(),
 
//         message,
 
//         link: `/tasks/${updatedTask.task_id}`
 
//       });
 
//       await reassignedNotification.save();
 
//     } else {
 
//       // Generic update notification for the current assignee
 
//       const updateNotification = new Notification({
 
//         recipientId: updatedTask.assignedTo.toString(),
 
//         message,
 
//         link: `/tasks/${updatedTask.task_id}`
 
//       });
 
//       await updateNotification.save();
 
//     }
 
//     res.status(200).json({
 
//       message: 'Task updated successfully',
 
//       task: updatedTask
 
//     });
 
//   } catch (err) {
 
//     res.status(500).json({
 
//       message: 'Failed to update task',
 
//       error: err.message
 
//     });
 
//   }
 
// };
 
// Delete Task permanenly
exports.deleteTaskPermanent= async (req, res) => {
  try {
    const deletedTask = await Task.findOneAndDelete({ task_id: req.params.task_id });
 
    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    res.status(200).json({ message: 'Task deleted successfully' });
 
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete task', error: err.message });
  }
};
 
 
// Soft Delete Task
exports.deleteTask = async (req, res) => {
  try {
    const deletedTask = await Task.findOneAndUpdate(
      { task_id: req.params.task_id },
      { isDeleted: true },
      { new: true }
    );
 
    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    res.status(200).json({ message: 'Task soft-deleted successfully' });
 
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete task', error: err.message });
  }
};
 
 
// Update Task Status
exports.updateTaskStatus = async (req, res) => {
  const { task_id } = req.params;
  const { status, feedback } = req.body;
 
  try {
    const task = await Task.findOne({ task_id, isDeleted: false });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    // If changing to 'Completed'
   if (status === 'Completed') {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const deadlineStr = task.deadline?.toISOString().split('T')[0];
 
  const isLate = deadlineStr && todayStr > deadlineStr;
 
  if (isLate && (!feedback || feedback.trim() === '')) {
    return res.status(400).json({
      message: 'Task is completed after the deadline. Feedback is required for the delay.'
    });
  }
 
  task.completedAt = now;
  task.isLate = isLate;
  task.completionFeedback = isLate ? feedback : undefined;
}
 
    task.status = status;
    await task.save();
 
    res.json({ message: 'Task status updated successfully', task });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
 
 
// Get tasks by assignee
exports.getTasksByAssignee = async (req, res) => {
  try {
    const { assignedTo } = req.body;
    const tasks = await Task.find({ assignedTo }).sort({ dueDate: 1 });
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
 
 
 
 
 
exports.reviewTask = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { reviewedBy, reviewStatus } = req.body;
 
    const task = await Task.findOne({ task_id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
 
    task.reviewedBy = reviewedBy;
    task.reviewStatus = reviewStatus;
 
    if (reviewStatus === 'Accepted') {
      task.status = 'Completed';
      task.completedAt = new Date();
    }
 
    await task.save();
 
    // Send notification to the task assignee
    const notificationMessage = `Your task "${task.title}" has been reviewed and marked as "${reviewStatus}".`;
 
    const notification = new Notification({
      recipientId: task.assignedTo.toString(), // Make sure this is a string ID
      message: notificationMessage,
      link: `/tasks/${task.task_id}`, // Adjust the link format as needed
    });
 
    await notification.save();
 
    res.status(200).json({ message: 'Task reviewed successfully', task });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
// Get all tasks by projectiD AND projectName
exports. getAllTask = async (req, res) => {
  try {
    const tasks = await Task.find({isDeleted: false}).populate('projectId', 'projectName');
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving tasks', error });
  }
};
 
 
 
 
 
 
 exports.getTasksByDeadline = async (req, res) => {
  try {
    // Set start of today
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0); // 00:00:00
 
    // Set end of 7th day from today
    const endOfNext7Days = new Date();
    endOfNext7Days.setDate(startOfToday.getDate() + 7);
    endOfNext7Days.setHours(23, 59, 59, 999); // 23:59:59
 
    const tasks = await Task.find({
      deadline: {
        $gte: startOfToday,
        $lte: endOfNext7Days
      },
      isDeleted: false
    });
 
    res.status(200).json({
      success: true,
      count: tasks.length,
      data: tasks
    });
  } catch (error) {
    console.error('Error fetching upcoming deadline tasks:', error);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error'
    });
  }
};
// Link a bug to a task
exports.linkBugToTask = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { bug_id } = req.body;
 
    const task = await Task.findOne({ task_id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
 
    const bug = await Bug.findOne({ bug_id });
    if (!bug) return res.status(404).json({ message: 'Bug not found' });
 
    // prevent duplicate
    if (!task.bugIds.includes(bug_id)) {
      task.bugIds.push(bug_id);
    }
 
    task.status = 'In Progress';
    task.reviewStatus = 'Rejected';
    await task.save();
 
    res.status(200).json({ message: 'Bug linked to task successfully', task });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
 
 
// Get project task summary
exports.getProjectTaskSummary = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    const now = new Date();
    const threeDaysLater = new Date();
    threeDaysLater.setDate(now.getDate() + 3);
 
    const totalTasks = await Task.countDocuments({ projectId });
    const completedTasks = await Task.countDocuments({ projectId, status: 'Completed' });
    const inProgressTasks = await Task.countDocuments({ projectId, status: 'In Progress' });
    const pendingTasks = await Task.countDocuments({ projectId, status: 'Pending' });
 
    const tasksExpiringSoon = await Task.countDocuments({
      projectId,
      deadline: { $gte: now, $lte: threeDaysLater }
    });
 
    res.status(200).json({
      projectId,
      totalTasks,
      completedTasks,
      inProgressTasks,
      pendingTasks,
      tasksExpiringSoon
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
 
 
 
// exports.getTasksByprojectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const tasks = await Task.find({ projectId }).sort({ dueDate: 1 });
//     res.json(tasks);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };
 exports.getTasksByprojectId = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    // 1. Fetch tasks for the project
    const tasks = await Task.find({ projectId, isDeleted: false }).sort({ dueDate: 1 });
 
    // 2. Fetch team by projectId
    const team = await Team.findOne({ projectId, isDeleted: false });
    if (!team) {
      return res.status(404).json({ message: 'Team not found for this project' });
    }
 
    // 3. Map over tasks and attach member details from team
    const enrichedTasks = tasks.map(task => {
      const assignedMember = team.teamMembers.find(member => member.memberId === task.assignedTo);
 
      return {
        ...task.toObject(),
        assignedToDetails: assignedMember ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role
        } : null
      };
    });
 
    res.json(enrichedTasks);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
};
 
 
 
exports.getTaskCounts = async (req, res) => {
    try {
        // Get today's date boundaries
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
 
        // Count all tasks (excluding deleted ones)
        const totalTasks = await Task.countDocuments({ isDeleted: false });
 
        // Count tasks with deadline today
        const todayTasks = await Task.countDocuments({
            isDeleted: false,
            deadline: {
                $gte: today,
                $lt: tomorrow
            }
        });
 
        res.status(200).json({
            success: true,
            data: {
                totalTasks,
                todayDeadlineTasks: todayTasks
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching task counts',
            error: error.message
        });
    }
};

exports.updateTaskStatusById = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { status } = req.body;
 
    // Validate status
    const validStatuses = ['Pending', 'In Progress', 'Completed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be Pending, In Progress, or Completed.',
      });
    }
 
    const task = await Task.findOne({ task_id });
 
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found',
      });
    }
 
    task.status = status;
 
    // If task is marked completed, set completedAt
    if (status === 'Completed' && !task.completedAt) {
      task.completedAt = new Date();
 
      if (task.deadline && new Date() > new Date(task.deadline)) {
        task.isLate = true;
      }
    }
 
    await task.save();
 
    res.status(200).json({
      success: true,
      message: 'Task status updated successfully',
      task,
    });
  } catch (err) {
    console.error('Error updating task status:', err);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
    });
  }
};


exports.updateReviewStatus = async (req, res) => {
  try {
    const { task_id } = req.params;
    const { reviewStatus } = req.body;
 
    const validStatuses = ['N/A', 'InReview', 'BugReported', 'Resolved'];
    if (!validStatuses.includes(reviewStatus)) {
      return res.status(400).json({ message: 'Invalid review status value' });
    }
 
    const task = await Task.findOne({ task_id });
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
 
    task.reviewStatus = reviewStatus;
    await task.save();
 
    //  Push to history (skip if already Resolved)
    await pushTaskHistory(task_id, {
      action: 'Review Status Updated',
      reviewStatus
    });
 
    //  Send notification if status is "Resolved"
    if (reviewStatus === 'Resolved') {
      const notification = new Notification({
        recipientId: task.assignedTo?.toString(), // Dynamic recipient
        message: `Your task "${task.title}" has been marked as Resolved.`,
        link: `/tasks/${task.task_id}`
      });
      await notification.save();
    }
 
    return res.status(200).json({
      message: 'Review status updated successfully',
      updatedReviewStatus: task.reviewStatus
    });
 
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Server error', error: error.message });
  }
};


exports.exportTasks = async (req, res) => {
  try {
    const { projectId, employeeId, filterObj = {} } = req.body;
 
    if (!projectId) {
      return res.status(400).json({ message: "projectId is required" });
    }
 
    // Build query
    let query = { projectId };
 
    if (employeeId) {
      query.employeeId = employeeId;
    }
 
    if (filterObj.priority) {
      query.priority = filterObj.priority;
    }
 
    if (filterObj.status) {
      query.status = filterObj.status;
    }
 
    if (filterObj.assignedTo) {
      // Case-insensitive & partial match
      query.assignedTo = { $regex: filterObj.assignedTo.trim(), $options: "i" };
    }
 
    // Date range filter
    if (filterObj.dateFrom || filterObj.dateTo) {
      query.createdAt = {};
      if (filterObj.dateFrom) {
        query.createdAt.$gte = new Date(filterObj.dateFrom);
      }
      if (filterObj.dateTo) {
        query.createdAt.$lte = new Date(filterObj.dateTo);
      }
    }
 
    // Fetch matching tasks
    const tasks = await Task.find(query).lean();
 
    if (!tasks.length) {
      return res.status(404).json({ message: "No tasks found for given filters" });
    }
 
    // Create Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Tasks");
 
    worksheet.columns = [
      { header: "Task ID", key: "task_id", width: 15 },
      { header: "Project ID", key: "projectId", width: 20 },
      { header: "Project Name", key: "projectName", width: 20 },
      { header: "Title", key: "title", width: 25 },
      { header: "Status", key: "status", width: 15 },
      { header: "Priority", key: "priority", width: 15 },
      { header: "Assigned To", key: "assignedTo", width: 20 },
      { header: "Deadline", key: "deadline", width: 20 },
      { header: "Created At", key: "createdAt", width: 20 }
    ];
 
    // Add task rows
    tasks.forEach(task => {
      worksheet.addRow({
        task_id: task.task_id,
        projectId: task.projectId,
        projectName: task.projectName,
        title: task.title,
        status: task.status,
        priority: task.priority,
        assignedTo: task.assignedTo,
        deadline: task.deadline ? task.deadline.toISOString().split("T")[0] : "",
        createdAt: task.createdAt ? task.createdAt.toISOString().split("T")[0] : ""
      });
    });
 
    // Send Excel file
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=tasks_${Date.now()}.xlsx`
    );
 
    await workbook.xlsx.write(res);
    res.end();
 
  } catch (error) {
    console.error("Error exporting tasks:", error);
    res.status(500).json({ message: "Error generating Excel file" });
  }
};



const Team = require('../../Model/TeamModel/Team');
const Project = require('../../Model/ProjectModel/projectModel');
const Notification = require('../../Model/NotificationModel/notificationModel');

// Create team
exports.createTeam = async (req, res) => {
  try {
    const { projectId, teamLeadId, teamMembers } = req.body;

    if (!projectId || !teamLeadId) {
      return res.status(400).json({ message: 'projectId and teamLeadId are required' });
    }

    const project = await Project.findOne({ projectId });

    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const projectName = project.projectName;
    const teamLeadName = project.teamLeadName || 'Unknown Lead';

    if (!teamMembers || !Array.isArray(teamMembers) || teamMembers.length === 0) {
      return res.status(400).json({ message: 'At least one team member is required' });
    }

    for (const member of teamMembers) {
      if (!member.memberId || !member.role) {
        return res.status(400).json({ message: 'Each team member must have memberId and role' });
      }
    }

    // const teamLeadIncluded = teamMembers.some(member => member.memberId === teamLeadId);
    // if (teamLeadIncluded) {
    //   return res.status(400).json({ message: 'Team Lead cannot be added as a team member' });
    // }

    const prefix = projectName.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-+$/, '');
    const regex = new RegExp(`^${prefix}-\\d{3}$`);
    const teamCount = await Team.countDocuments({ teamId: { $regex: regex } });
    const teamId = `${prefix}-${String(teamCount + 1).padStart(3, '0')}`;

    const team = new Team({
      teamId,
      projectId,
      projectName,
      teamLeadId,
      teamLeadName,
      teamMembers,
      createdAt: new Date(),
      updatedAt: new Date()
    });

    await team.save();

    //  Send notifications to all team members
    const notifications = teamMembers.map(member => ({
      recipientId: member.memberId,
      message: `You have been added to the team for project "${projectName}" under Team Lead ${teamLeadName}.`,
      link: `/teams/${teamId}`, // Optional link
      createdAt: new Date()
    }));

    await Notification.insertMany(notifications); // Bulk insert

    return res.status(201).json({
      message: 'Team created successfully and notifications sent to team members',
      team
    });

  } catch (error) {
    console.error('Error in createTeam:', error);
    return res.status(500).json({ message: 'Internal server error', error: error.message });
  }
};


// Get All Teams (excluding deleted)
exports.getAllTeams = async (req, res) => {
  try {
    const teams = await Team.find({ isDeleted: false });
    res.status(200).json(teams);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching teams', error });
  }
};

// Get Team by teamId 
exports.getTeamById = async (req, res) => {
  try {
    const team = await Team.findOne({ teamId: req.params.teamId, isDeleted: false });

    if (!team) {
      return res.status(404).json({ message: 'Team not found' });
    }

    res.status(200).json(team);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching team', error });
  }
};


exports.updateTeam = async (req, res) => {
  try {
    const { teamMembers } = req.body;
    const teamId = req.params.teamId;

    const updatedTeam = await Team.findOneAndUpdate(
      { teamId, isDeleted: false },
      { teamMembers, updatedAt: Date.now() },
      { new: true }
    );

    if (!updatedTeam) {
      return res.status(404).json({ message: 'Team not found or deleted' });
    }

    // Fetch project name for context
    const project = await Project.findOne({ projectId: updatedTeam.projectId });
    const projectName = project?.projectName || 'Unknown Project';
    const teamLeadName = updatedTeam.teamLeadName || 'Team Lead';

    // Create notifications for all updated members
    const notifications = teamMembers.map(member => ({
      recipientId: member.memberId,
      message: `You have been assigned/updated in the team for project "${projectName}" under ${teamLeadName}.`,
      link: `/teams/${updatedTeam.teamId}`,
      createdAt: new Date()
    }));

    await Notification.insertMany(notifications);

    res.status(200).json({
      message: 'Team members updated successfully and notifications sent',
      team: updatedTeam
    });

  } catch (error) {
    console.error('Error updating team:', error);
    res.status(500).json({ message: 'Error updating team members', error: error.message });
  }
};



// Soft Delete Team
exports.deleteTeam = async (req, res) => {
  try {
    const deletedTeam = await Team.findOneAndUpdate(
      { teamId: req.params.teamId, isDeleted: false },
      { isDeleted: true, updatedAt: Date.now() },
      { new: true }
    );

    if (!deletedTeam) {
      return res.status(404).json({ message: 'Team not found or already deleted' });
    }

    res.status(200).json({ message: 'Team deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting team', error });
  }
};


exports.getAllTeamsByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;

    if (!projectId) {
      return res.status(400).json({ success: false, message: 'projectId is required' });
    }

    const teams = await Team.find({ projectId, isDeleted: false });

    if (!teams.length) {
      return res.status(404).json({ success: false, message: 'No teams found for this projectId' });
    }

    res.status(200).json({ success: true, data: teams });
  } catch (error) {
    console.error('Error fetching teams:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};








exports.getTeamMembersExcludingLead = async (req, res) => {
  try {
    const { teamId } = req.params;

    const team = await Team.findOne({ teamId, isDeleted: false });

    if (!team) {
      return res.status(404).json({ message: 'Team not found' });
    }

    const filteredMembers = team.teamMembers.filter(member => member.memberId !== team.teamLeadId);

    return res.status(200).json({
      message: 'Team members (excluding team lead) fetched successfully',
      teamId: team.teamId,
      members: filteredMembers
    });
  } catch (error) {
    console.error('Error fetching team members:', error);
    return res.status(500).json({ message: 'Server error', error });
  }
};


exports.getAllTeamLeadDetails = async (req, res) => {
  try {
    const leadDetails = await Team.aggregate([
      {
        $match: { isDeleted: false }
      },
      {
        $project: {
          _id: 0,
          teamLeadName: 1,
          projectName: 1,
          teamMembersCount: { $size: '$teamMembers' }
        }
      }
    ]);
 
    res.status(200).json({
      success: true,
      data: leadDetails
    });
  } catch (error) {
    console.error('Error fetching team lead details:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch team lead details',
      error: error.message
    });
  }
};



// Get all teams by memberId or teamLeadId
exports.getTeamsByUserId = async (req, res) => {
  const { userId } = req.params;
 
  if (!userId) {
    return res.status(400).json({ message: 'userId is required' });
  }
 
  try {
    const teams = await Team.find({
      isDeleted: false,
      $or: [
        { teamLeadId: userId },
        { teamMembers: { $elemMatch: { memberId: userId } } }
      ]
    });
 
    if (!teams.length) {
      return res.status(404).json({ message: 'No teams found for this user' });
    }
 
    res.status(200).json({ success: true, data: teams });
  } catch (error) {
    console.error('Error fetching teams:', error);
    res.status(500).json({ success: false, message: 'Server Error', error: error.message });
  }
};

exports.getTeamMembersByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    if (!projectId) {
      return res.status(400).json({ message: 'projectId is required' });
    }
 
    // Find all teams related to the project
    const teams = await Team.find({ projectId, isDeleted: false });
 
    if (!teams || teams.length === 0) {
      return res.status(404).json({ message: 'No teams found for this project' });
    }
 
    // Combine all teamMembers from all matched teams
    const allTeamMembers = teams.flatMap(team => team.teamMembers);
 
    return res.status(200).json({
      projectId,
      totalMembers: allTeamMembers.length,
      teamMembers: allTeamMembers
    });
  } catch (error) {
    console.error('Error fetching team members:', error);
    res.status(500).json({ message: 'Server error' });
  }
};



exports.softDeleteTeam = async (req, res) => {
  const { teamId } = req.params;
 
  try {
    const team = await Team.findOne({ teamId });
 
    if (!team) {
      return res.status(404).json({ message: 'Team not found' });
    }
 
    if (team.isDeleted) {
      return res.status(400).json({ message: 'Team is already deleted' });
    }
 
    team.isDeleted = true;
    team.updatedAt = new Date();
 
    await team.save();
 
    return res.status(200).json({ message: 'Team soft deleted successfully', team });
  } catch (error) {
    console.error('Soft delete error:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};
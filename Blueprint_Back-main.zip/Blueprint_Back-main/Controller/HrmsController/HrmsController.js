



// HrmsController.js
const transporter=require("../../middlewares/nodemailer");
const bcrypt = require("bcrypt");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
//const transporter = require("../../middlewares/nodemailer");
const sessionService = require('../../middlewares/sessionServices');
 const {sendEmail}=require('../../middlewares/nodemailer')
const { connections } = require("../../Config/db");
const getEmployeeModel = require("../../Model/HrmsModel/HrmsModel");
const getDepartmentModel=require("../../Model/HrmsModel/HrmsModel")
const fetchAllUser=require("../../Model/HrmsModel/HrmsModel");
const sendOtpForLogin=require("../../Model/HrmsModel/HrmsModel");
const verifyLoginOTP=require("../../Model/HrmsModel/HrmsModel");
const getOtpVerificationModel = require("../../Model/HrmsModel/OtpVerificationModel");
const path = require("path");

 
exports.getAllHRMSEmployees = async (req, res) => {
  try {
    const { Employee } = getEmployeeModel(connections.hrms);
    const { Department } = getDepartmentModel(connections.hrms); // Assuming this exists
 
    // First find the IT department's _id
    const itDept = await Department.findOne({ name: 'IT' });
 
    if (!itDept) {
      return res.status(404).json({ message: 'IT department not found' });
    }
 
    const employees = await Employee.find({ department: itDept._id });
 
    res.status(200).json(employees);
  } catch (error) {
    console.error("Failed to fetch IT department employees:", error);
    res.status(500).json({ message: "Error fetching employees", error });
  }
};
 
 
exports.fetchAllUsers = async (req, res) => {
  try{
    const { User } = fetchAllUser(connections.hrms);
      const users = await User.find({isDeleted: false});
      if(!users || users.length === 0){
          return res.status(400).json({message:"USER NOT FOUND"});
      }
      // Map through the users array and extract the relevant fields
      const userDetails = users.map(user => ({
          fullName: user.fullName,
          email: user.email,
          username: user.username,
          contact: user.contact,
          role: user.role,
          id: user.userId,
          profilePicture: user.profilePicture,
          filetype: user.profileImageType,
          isDeleted: user.isDeleted,
          rolePriority: user.rolePriority
      }));
 
     // userDetails.sort((a, b) => a.rolePriority - b.rolePriority);
     
      return res.status(200).json(userDetails);
  }catch(error) {
      console.log(error);
      return res.status(500).json({message:"Server Error", error});
  }
};
 
 
const validateEmailFormat = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
 
 
 
 
 
 
 
exports.sendOtpForLogin = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { User } = sendOtpForLogin(connections.hrms); // HRMS DB (read-only)
    const OtpVerification = getOtpVerificationModel(connections.main); // Main DB (writable)
 
    // Validate email format
    if (!validateEmailFormat(email)) {
      return res.status(400).json({ message: "Invalid email format" });
    }
 
    // Find user in HRMS DB
    const user = await User.findOne({ email, isDeleted: false });
    if (!user) {
      return res.status(404).json({ message: "Email does not exist" });
    }
 
    // Check existing OTP record in Main DB
    let otpRecord = await OtpVerification.findOne({ email });
 
    // Check if account is frozen
    if (otpRecord && otpRecord.freezeUntil && otpRecord.freezeUntil > Date.now()) {
      return res.status(400).json({
        message: "Your account is currently frozen. Please try again later.",
      });
    }
 
    // Check password
    const isPasswordMatch = await user.comparePassword(password);
    if (!isPasswordMatch) {
      if (!otpRecord) {
        otpRecord = await OtpVerification.create({ email, failedAttempts: 0 });
      }
      otpRecord.failedAttempts += 1;
      if (otpRecord.failedAttempts >= 3) {
        otpRecord.freezeUntil = Date.now() + 15 * 60 * 1000; // 15 mins
      }
      await otpRecord.save();
      return res.status(401).json({
        message: "Invalid credentials: either email or password",
      });
    }
 
    // Generate OTP
    const otp = crypto.randomInt(100000, 999999).toString();
    const hashedLoginOtp = await bcrypt.hash(otp, 10);
    const tokenExpireTime = Date.now() + 10 * 60 * 1000;//token expried at 10 minutes from now
 
    // Update or create OTP record
    if (otpRecord) {
      otpRecord.loginOTP = hashedLoginOtp;
      otpRecord.tokenExpireTime = tokenExpireTime;
      otpRecord.failedAttempts = 0;
      otpRecord.freezeUntil = null;
      await otpRecord.save();
    } else {
      await OtpVerification.create({
        email,
        loginOTP: hashedLoginOtp,
        tokenExpireTime,
        failedAttempts: 0,
        freezeUntil: null,
      });
    }
 
    // HTML Email Template
    const emailContentForLogin = `
      <html>
        <body style="font-family: Arial, sans-serif; color: #333;">
          <p>We received a request for Login. To complete the login, please use the following One-Time-Password (OTP):</p>
          <p style="font-size: 20px; text-align:center; font-weight: bold; color:rgb(68, 152, 231);">${otp}</p>
          <p>This OTP is valid for the next 10 minutes. Please do not share this OTP with anyone for security reasons.</p>
          <p>If you did not request this, please ignore this email.</p>
          <p>Thank you for using our service!</p>
          <p>Best Regards,<br>AAS International</p>
        </body>
      </html>
    `;
 
    // Email sending
    // const mailingOptions = {
    //   from: process.env.EMAIL_ID,
    //   to: user.email,
    //   subject: "Your HRMS Login OTP: Secure Access Code Inside",
    //   html: emailContentForLogin,
    // };
 
    await sendEmail('Login OTP',emailContentForLogin,email);
 
    return res.status(200).json({
      message: "OTP sent successfully",
      // user: {
      //   email: user.email,
      //   username: user.username,
      //   fullName: user.fullName,
      //   role: user.role,
      //   userId: user.userId,
      // },
    });
  } catch (error) {
    console.error("Send OTP Error:", error);
    return res.status(500).json({ message: "Invalid Credenetials", error });
  }
};
 
 
 
 
 
 
const generateToken = (payload) => {
    return jwt.sign(payload, process.env.JWT_SECRET_KEY, { expiresIn: "1d" });
};
 
 
exports.verifyLoginOTP = async (req, res) => {
  try {
    const { email, otp } = req.body;
    const { User, Employee } = verifyLoginOTP(connections.hrms);
    const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
    const OtpVerification = getOtpVerificationModel(connections.main);
 
    // Initialize session service
    const { verifyOTPAndCreateSession } = sessionService(User, Session, OtpVerification);
 
    // Get device info and IP address from request
    const deviceInfo = req.headers['user-agent'] || 'Unknown';
    const ipAddress = req.ip || 'Unknown';
    const token=generateToken({id:User._id,role:User.role})
    // Verify OTP and create session
    // console.log(token);
   
    const { session, user } = await verifyOTPAndCreateSession(email, otp, deviceInfo, ipAddress);
 
    // Find employee data
    const employee = await Employee.findOne({ email });
    const employeeID = employee ? employee.employeeID : null;
 
    // Set session token in HTTP-only cookie
    res.cookie('token', token, {
      httpOnly: true,
      secure: true,
      maxAge:  24 * 60 * 60 * 1000, // 1 days
      sameSite: 'None',
      path: '/',
    });
    res.cookie('email', email, {
      httpOnly: true,
      secure: true,
      maxAge: 24 * 60 * 60 * 1000, // 1days
      sameSite: 'None',
      path: '/',
    });
 
    return res.status(200).json({
      message: 'Login successful',
     
    });
  } catch (error) {
    console.error('OTP Verification Error:', error.message);
    return res.status(400).json({ message: error.message });
  }
};
 
 
exports.getUserByEmail = async (req, res) => {
  try {
    const { email } = req.params; // Expect email in request body
    const { User, Employee } = verifyLoginOTP(connections.hrms);
 
    // Find user in HRMS DB
    const user = await User.findOne({ email }).select('-password'); // Exclude password
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
 
    const employee = await Employee.findOne({ email });
    const employeeData = employee ? employee.toObject() : null;
 
 
 
    // Return only the message for consistency
    return res.status(200).json({ message: "User data retrieved successfully", user , employeeData});
  } catch (error) {
    console.error("User Fetch Error:", error);
    return res.status(500).json({ message: "Error fetching user data" });
  }
};
 
 

 
exports.logout = async (req, res) => {
  try {
    const cookieOptions = {
      httpOnly: true,
      secure: true, // set to true if using HTTPS in production
      sameSite: 'None',
      path: '/',
    };
 
    res.clearCookie('token', cookieOptions);
    res.clearCookie('email', cookieOptions);
 
    return res.status(200).json({ message: "Logout successful" });
  } catch (error) {
    console.error("Logout Error:", error);
    return res.status(500).json({ message: "Error logging out", error: error.message });
  }
};
 
 
exports.logoutAllDevices = async (req, res) => {
  try {
    const email = req.cookies.email || req.body.email;
    if (!email) {
      return res.status(400).json({ message: 'Email required for logout' });
    }
 
    const Session = require('../../Model/HrmsModel/sessionModel')(connections.main);
    const { deleteAllSessions } = sessionService(null, Session, null);
 
    await deleteAllSessions(email);
 
    res.clearCookie('sessionToken', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'None',
    });
    res.clearCookie('email', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'None',
    });
 
    return res.status(200).json({ message: 'Successfully logged out from all devices' });
  } catch (error) {
    console.error('Logout All Devices Error:', error);
    return res.status(500).json({ message: 'Error logging out from all devices', error: error.message });
  }
};
 
// controllers/userController.js
exports.getUserByEmailFromCookie = async (req, res) => {
  try {
    const email = req.cookies.email; // Fetch email from cookies
    if (!email) {
      return res.status(400).json({ message: "Email cookie is missing" });
    }
 
    const { User, Employee } = verifyLoginOTP(connections.hrms);
 
    const user = await User.findOne({ email }).select('-password');
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
 
    const employee = await Employee.findOne({ email });
    const employeeData = employee ? employee.toObject() : null;
 
    return res.status(200).json({
      message: "User and employee data retrieved successfully",
      user,
      employee: employeeData,
    });
  } catch (error) {
    console.error("Fetch User by Cookie Error:", error);
    return res.status(500).json({ message: "Error fetching user data", error: error.message });
  }
};
 
 
 
exports.checkToken = async (req, res) => {
    try{
       
        const token  = req.cookies.token;
       
       
        const isPresent = !!token;
 
        if(!isPresent){
            return res.status(200).json({message: "Token is not present", dashboard: false});
        }
        return res.status(200).json({message: "Token is present", dashboard: true});
 
    }catch(error){
        console.log(error);
        return res.status(500).json({message: "Internal Server error, please try again later", error: error.message});
    }
}

const Bug = require('../../Model/BugModel/Bug');
const Task = require('../../Model/TaskModel/Task');
const Notification = require('../../Model/NotificationModel/notificationModel');
const Project=require("../../Model/ProjectModel/projectModel")
const Team=require("../../Model/TeamModel/Team")
const ExcelJS = require('exceljs');
const pushTaskHistory = require('../../utils/pushTaskHistory');

// exports.createBug = async (req, res) => {
//   try {
//     const { title, description, task_id, priority } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     // Update task status to "In Progress" if not already
//     task.status = "In Progress";
//     await task.save();
 
//     const bugData = {
//       title,
//       description,
//       priority,
//       taskRef: task.task_id,
//       assignedTo: task.memberId,
//       projectId: task.projectId
//     };
 
//     const newBug = await Bug.createBugWithId(bugData);
 
//     // Create notification for the task member
//     const notification = new Notification({
//       recipientId: task.memberId.toString(),
//       message: `A bug has been reported for your task "${task.title}": "${title}".`,
//       link: `/bugs/${newBug.bug_id}`
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Bug created successfully and task status updated to In Progress',
//       bug: newBug
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
//  exports.createBug = async (req, res) => {
//   try {
//     const { title, description, task_id, priority, deadline } = req.body; // ✅ added deadline
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     // Update task status to "In Progress" if not already
//     task.status = "In Progress";
//     await task.save();
 
//     const bugData = {
//       title,
//       description,
//       priority,
//       deadline, // include deadline in bugData
//       taskRef: task.task_id,
//       assignedTo: task.memberId,
//       projectId: task.projectId
//     };
 
//     const newBug = await Bug.createBugWithId(bugData);
 
//     // Create notification for the task member
//     const notification = new Notification({
//       recipientId: task.memberId.toString(),
//       message: `A bug has been reported for your task "${task.title}": "${title}".`,
//       link: `/bugs/${newBug.bug_id}`
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Bug created successfully and task status updated to In Progress',
//       bug: newBug
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 






// exports.createBug = async (req, res) => {
//   try {
//     const { title, description, task_id, priority, deadline } = req.body;
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     // ✅ Update reviewStatus to "BugReported"
//     task.status = "In Progress";
//     task.reviewStatus = "BugReported";
//     await task.save();
 
//     const bugData = {
//       title,
//       description,
//       priority,
//       deadline,
//       taskRef: task.task_id,
//       assignedTo: task.memberId,
//       projectId: task.projectId
//     };
 
//     const newBug = await Bug.createBugWithId(bugData);
 
//     // Notification to the assigned task member
//     const notification = new Notification({
//       recipientId: task.memberId.toString(),
//       message: `A bug has been reported for your task "${task.title}": "${title}".`,
//       link: `/bugs/${newBug.bug_id}`
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Bug created successfully and task updated with BugReported status',
//       bug: newBug
//     });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
exports.createBug = async (req, res) => {
  try {
    const { title, description, task_id, priority, deadline } = req.body;
 
    const task = await Task.findOne({ task_id });
    if (!task) return res.status(404).json({ message: 'Task not found' });
 
    // Update reviewStatus to "BugReported"
    task.status = "In Progress";
    task.reviewStatus = "BugReported";
    await task.save();
 
    const bugData = {
      title,
      description,
      priority,
      deadline,
      taskRef: task.task_id,
      assignedTo: task.memberId,
      projectId: task.projectId
    };
 
    const newBug = await Bug.createBugWithId(bugData);
 
    //  Push history (only if reviewStatus is not Resolved)
    await pushTaskHistory(task.task_id, {
      action: 'Bug Reported',
      reviewStatus: task.reviewStatus,
      bug_id: newBug.bug_id,
      bugTitle: newBug.title,
      bugStatus: newBug.status
    });
 
    // Notification to the assigned task member
    const notification = new Notification({
      recipientId: task.memberId.toString(),
      message: `A bug has been reported for your task "${task.title}": "${title}".`,
      link: `/bugs/${newBug.bug_id}`
    });
 
    await notification.save();
 
    res.status(201).json({
      message: 'Bug created successfully and task updated with BugReported status',
      bug: newBug
    });
 
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
// exports.resolveBug = async (req, res) => {
//   try {
//     const { bug_id } = req.params;
 
//     // Step 1: Find the bug
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) {
//       return res.status(404).json({ message: 'Bug not found' });
//     }
 
//     if (bug.status === 'Resolved') {
//       return res.status(400).json({ message: 'Bug is already resolved' });
//     }
 
//     // Step 2: Resolve the bug
//     bug.status = 'Resolved';
//     bug.resolvedAt = new Date();
//     await bug.save();
 
//     // Step 3: Get the associated task
//     const task = await Task.findOne({ task_id: bug.taskRef });
//     if (!task) {
//       return res.status(404).json({ message: 'Associated task not found' });
//     }
 
//     // Step 4: Check if all bugs for this task are resolved
//     const unresolvedBugs = await Bug.find({
//       taskRef: task.task_id,
//       status: { $ne: 'Resolved' }
//     });
 
//     let taskUpdated = null;
 
//     if (unresolvedBugs.length === 0) {
//       // ✅ All bugs resolved: mark task as Completed
//       task.status = 'Completed';
//       task.completedAt = new Date();
//       task.reviewStatus = 'InReview'; // ✅ Stay in review even if completed
//       taskUpdated = task;
 
//       // Step 5: Notify Team Lead
//       const team = await Team.findOne({ projectId: task.projectId, isDeleted: false });
//       if (team && team.teamLeadId) {
//         const notification = new Notification({
//           recipientId: team.teamLeadId.toString(),
//           message: `Task "${task.title}" has been marked as completed after all bugs were resolved.`,
//           link: `/tasks/${task.task_id}`
//         });
//         await notification.save();
//       }
//     } else {
//       // ✅ Partial bug resolution: still mark as InReview
//       task.reviewStatus = 'InReview';
//     }
 
//     await task.save(); // Save final task state
 
//     res.status(200).json({
//       message: `Bug ${bug.bug_id} resolved successfully`,
//       bug,
//       taskUpdated
//     });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };



// exports.resolveBug = async (req, res) => {
//   try {
//     const { bug_id } = req.params;
 
//     // Step 1: Find the bug
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) {
//       return res.status(404).json({ message: 'Bug not found' });
//     }
 
//     if (bug.status === 'Resolved') {
//       return res.status(400).json({ message: 'Bug is already resolved' });
//     }
 
//     // Step 2: Resolve the bug
//     bug.status = 'Resolved';
//     bug.resolvedAt = new Date();
//     await bug.save();
 
//     // Step 3: Get the associated task
//     const task = await Task.findOne({ task_id: bug.taskRef });
//     if (!task) {
//       return res.status(404).json({ message: 'Associated task not found' });
//     }
 
//     // Step 4: Check if all bugs for this task are resolved
//     const unresolvedBugs = await Bug.find({
//       taskRef: task.task_id,
//       status: { $ne: 'Resolved' }
//     });
 
//     let taskUpdated = null;
 
//     if (unresolvedBugs.length === 0) {
//       // Step 5: Mark task as completed
//       task.status = 'Completed';
//       task.completedAt = new Date();
//       task.reviewStatus = 'Accepted';
//       await task.save();
//       taskUpdated = task;
 
//       // Step 6: Fetch teamLeadId from Team collection using projectId
//       const team = await Team.findOne({ projectId: task.projectId, isDeleted: false });
//       if (team && team.teamLeadId) {
//         // Step 7: Send notification to team lead
//         const notification = new Notification({
//           recipientId: team.teamLeadId.toString(),
//           message: `Task "${task.title}" has been marked as completed after all bugs were resolved.`,
//           link: `/tasks/${task.task_id}`
//         });
//         await notification.save();
//       }
//     }
 
//     res.status(200).json({
//       message: `Bug ${bug.bug_id} resolved successfully`,
//       bug,
//       taskUpdated
//     });
 
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 

// exports.createBug = async (req, res) => {
//   try {
//     const { title, description, task_id, priority } = req.body; // <-- Include priority
 
//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     const bugData = {
//       title,
//       description,
//       priority, // <-- Add priority here
//       taskRef: task.task_id,
//       assignedTo: task.memberId,
//       projectId: task.projectId
//     };
 
//     const newBug = await Bug.createBugWithId(bugData);
 
//     // Create notification for the member assigned to the bug
//     const notification = new Notification({
//       recipientId: task.memberId.toString(),
//       message: `A bug has been reported for your task "${task.title}": "${title}".`,
//       link: `/bugs/${newBug.bug_id}` // Adjust link based on your route
//     });
 
//     await notification.save();
 
//     res.status(201).json({
//       message: 'Bug created successfully',
//       bug: newBug
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
 

// exports.createBug = async (req, res) => {
//   try {
//     const { title, description, task_id } = req.body;

//     const task = await Task.findOne({ task_id });
//     if (!task) return res.status(404).json({ message: 'Task not found' });

//     const bugData = {
//       title,
//       description,
//       taskRef: task.task_id,
//       assignedTo: task.memberId,
//       projectId: task.projectId
//     };

//     const newBug = await Bug.createBugWithId(bugData);

//     // Create notification for the member assigned to the bug
//     const notification = new Notification({
//       recipientId: task.memberId.toString(),
//       message: `A bug has been reported for your task "${task.title}": "${title}".`,
//       link: `/bugs/${newBug.bug_id}` // Adjust link based on your route
//     });

//     await notification.save();

//     res.status(201).json({
//       message: 'Bug created successfully',
//       bug: newBug
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };

// exports.resolveBug = async (req, res) => {
//   try {
//     const { bug_id } = req.params;

//     // Find bug by custom bug_id
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) {
//       return res.status(404).json({ message: 'Bug not found' });
//     }

//     if (bug.status === 'Resolved') {
//       return res.status(400).json({ message: 'Bug is already resolved' });
//     }

//     // Mark the bug as resolved
//     bug.status = 'Resolved';
//     bug.resolvedAt = new Date();
//     await bug.save();

//     // Now update task if all bugs linked to it are resolved
//     const task = await Task.findOne({ task_id: bug.taskRef });  // Fix here: use taskRef, not task_id
//     if (!task) {
//       return res.status(404).json({ message: 'Associated task not found' });
//     }

//     // Check if all bugs linked to this task are resolved
//     const unresolvedBugs = await Bug.find({ taskRef: task.task_id, status: { $ne: 'Resolved' } }); // Fix here: use taskRef in Bug query

//     if (unresolvedBugs.length === 0) {
//       task.status = 'Completed';
//       task.completedAt = new Date();
//       task.reviewStatus = 'Accepted';
//       await task.save();
//     }

//     res.status(200).json({
//       message: `Bug ${bug.bug_id} resolved successfully`,
//       bug,
//       taskUpdated: unresolvedBugs.length === 0 ? task : null
//     });
//   } catch (err) {
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };
exports.resolveBug = async (req, res) => {
  try {
    const { bug_id } = req.params;
    const { delayReason } = req.body; // Extract delayReason
 
    // Step 1: Find the bug
    const bug = await Bug.findOne({ bug_id });
    if (!bug) {
      return res.status(404).json({ message: 'Bug not found' });
    }
 
    if (bug.status === 'Resolved') {
      return res.status(400).json({ message: 'Bug is already resolved' });
    }
 
    const now = new Date();
 
    // Only check delayReason if resolving after deadline
    if (bug.deadline && now > new Date(bug.deadline)) {
      if (!delayReason || delayReason.trim() === '') {
        return res.status(400).json({
          message: 'Bug is resolved after the deadline. Please provide a delayReason.'
        });
      }
      bug.isLate = true;
      bug.delayReason = delayReason;
    }
 
    // Step 2: Resolve the bug
    bug.status = 'Resolved';
    bug.resolvedAt = now;
    await bug.save();
 
    // Step 3: Get the associated task
    const task = await Task.findOne({ task_id: bug.taskRef });
    if (!task) {
      return res.status(404).json({ message: 'Associated task not found' });
    }
 
    // Step 4: Check if all bugs for this task are resolved
    const unresolvedBugs = await Bug.find({
      taskRef: task.task_id,
      status: { $ne: 'Resolved' }
    });
 
    let taskUpdated = null;
 
    if (unresolvedBugs.length === 0) {
      // All bugs resolved: mark task as Completed
      task.status = 'Completed';
      task.completedAt = new Date();
      task.reviewStatus = 'InReview'; // Stay in review even if completed
      taskUpdated = task;
 
      // Step 5: Notify Team Lead
      const team = await Team.findOne({ projectId: task.projectId, isDeleted: false });
      if (team && team.teamLeadId) {
        const notification = new Notification({
          recipientId: team.teamLeadId.toString(),
          message: `Task "${task.title}" has been marked as completed after all bugs were resolved.`,
          link: `/tasks/${task.task_id}`
        });
        await notification.save();
      }
    } else {
      // Partial bug resolution: still mark as InReview
      task.reviewStatus = 'InReview';
    }
 
    await task.save(); // Save final task state
 
    res.status(200).json({
      message: `Bug ${bug.bug_id} resolved successfully`,
      bug,
      taskUpdated
    });
 
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
exports.getallbugs = async (req, res) => {
  try {
    const bugs = await Bug.find().sort({ createdAt: -1 });
    res.status(200).json(bugs);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
// exports.getallbugByProjectId = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const bugs = await Bug.find({ projectId }).sort({ dueDate: 1 });
//     res.json(bugs);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };
// exports.getbugBybug_id = async (req, res) => {
//   try {
//     const { bug_id } = req.params;
//     const bugs = await Bug.find({ bug_id }).sort({ dueDate: 1 });
//     res.json(bugs);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// };

exports.getallbugByProjectId = async (req, res) => {

  try {

    const { projectId } = req.params;
 
    // 1. Fetch bugs for the project

    const bugs = await Bug.find({ projectId }).sort({ dueDate: 1 });
 
    // 2. Fetch all teams linked to this project

    const teams = await Team.find({ projectId, isDeleted: false });
 
    // 3. Combine all team members from all teams (if multiple teams per project)

    const allMembers = teams.flatMap(team => team.teamMembers);
 
    // 4. Enrich each bug with assignedToDetails

    const enrichedBugs = bugs.map(bug => {

      const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
      return {

        ...bug.toObject(),

        assignedToDetails: assignedMember ? {

          _id: assignedMember._id,

          memberId: assignedMember.memberId,

          memberName: assignedMember.memberName,

          email: assignedMember.email,

          role: assignedMember.role

        } : null

      };

    });
 
    res.json(enrichedBugs);

  } catch (err) {

    console.error('Error in getallbugByProjectId:', err);

    res.status(500).json({ error: err.message });

  }

};
 
exports.getbugBybug_id = async (req, res) => {
  try {
    const { bug_id } = req.params;
 
    // 1. Fetch all bugs by bug_id
    const bugs = await Bug.find({ bug_id }).sort({ dueDate: 1 });
 
    if (!bugs.length) {
      return res.status(404).json({ message: 'No bugs found with this ID' });
    }
 
    // 2. Extract projectId from the first bug (assuming all have same projectId)
    const projectId = bugs[0].projectId;
    const teams = await Team.find({ projectId, isDeleted: false });
 
    const allMembers = teams.flatMap(team => team.teamMembers);
 
    // 3. Enrich each bug with assignedToDetails
    const enrichedBugs = bugs.map(bug => {
      const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
      return {
        ...bug.toObject(),
        assignedToDetails: assignedMember ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role
        } : null
      };
    });
 
    res.json(enrichedBugs);
  } catch (err) {
    console.error('Error in getbugBybug_id:', err);
    res.status(500).json({ error: err.message });
  }
};
exports.fetchBugsByAssignedTo = async (req, res) => {
  try {
    const { assignedTo } = req.params;

    if (!assignedTo) {
      return res.status(400).json({ message: 'assignedTo parameter is required' });
    }

    // Fetch bugs by assignedTo
    const bugs = await Bug.find({ assignedTo }).sort({ createdAt: -1 });

    if (!bugs.length) {
      return res.status(404).json({ message: 'No bugs found for the given employee' });
    }

    // Extract unique projectIds from these bugs
    const projectIds = [...new Set(bugs.map(bug => bug.projectId))];

    // Fetch teams related to these projects
    const teams = await Team.find({ projectId: { $in: projectIds }, isDeleted: false });

    // Flatten all team members
    const allMembers = teams.flatMap(team => team.teamMembers);

    // Fetch all taskIds from bugs to batch query tasks
    const taskIds = bugs.map(bug => bug.taskRef);
    const tasks = await Task.find({ task_id: { $in: taskIds } });

    // Map for quick lookup
    const taskMap = new Map(tasks.map(task => [task.task_id, task.reviewStatus]));

    // Fetch project names
    const projects = await Project.find({ projectId: { $in: projectIds } });
    const projectMap = new Map(projects.map(project => [project.projectId, project.projectName]));

    // Enrich bugs with assignedToDetails, reviewStatus, and projectName
    const enrichedBugs = bugs.map(bug => {
      const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);

      return {
        ...bug.toObject(),
        assignedToDetails: assignedMember ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role
        } : null,
        reviewStatus: taskMap.get(bug.taskRef) || 'N/A',
        projectName: projectMap.get(bug.projectId) || 'Unknown'
      };
    });

    res.status(200).json({ success: true, data: enrichedBugs });
  } catch (error) {
    console.error('Error fetching bugs:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};



// exports.fetchBugsByAssignedTo = async (req, res) => {

//   try {

//     const { assignedTo } = req.params;
 
//     if (!assignedTo) {

//       return res.status(400).json({ message: 'assignedTo parameter is required' });

//     }
 
//     // Fetch bugs by assignedTo

//     const bugs = await Bug.find({ assignedTo }).sort({ createdAt: -1 });
 
//     if (!bugs.length) {

//       return res.status(404).json({ message: 'No bugs found for the given employee' });

//     }
 
//     // Extract unique projectIds from these bugs

//     const projectIds = [...new Set(bugs.map(bug => bug.projectId))];
 
//     // Fetch teams related to these projects

//     const teams = await Team.find({ projectId: { $in: projectIds }, isDeleted: false });
 
//     // Flatten all team members

//     const allMembers = teams.flatMap(team => team.teamMembers);
 
//     // Enrich bugs with assignedToDetails

//     const enrichedBugs = bugs.map(bug => {

//       const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
//       return {

//         ...bug.toObject(),

//         assignedToDetails: assignedMember ? {

//           _id: assignedMember._id,

//           memberId: assignedMember.memberId,

//           memberName: assignedMember.memberName,

//           email: assignedMember.email,

//           role: assignedMember.role

//         } : null

//       };

//     });
 
//     res.status(200).json({ success: true, data: enrichedBugs });

//   } catch (error) {

//     console.error('Error fetching bugs:', error);

//     res.status(500).json({ success: false, message: 'Server Error' });

//   }

// };
 




// exports.fetchBugsByAssignedTo = async (req, res) => {

//   try {

//     const { assignedTo } = req.params;
 
//     if (!assignedTo) {

//       return res.status(400).json({ message: 'assignedTo parameter is required' });

//     }
 
//     // Fetch bugs by assignedTo

//     const bugs = await Bug.find({ assignedTo }).sort({ createdAt: -1 });
 
//     if (!bugs.length) {

//       return res.status(404).json({ message: 'No bugs found for the given employee' });

//     }
 
//     // Extract unique projectIds from these bugs

//     const projectIds = [...new Set(bugs.map(bug => bug.projectId))];
 
//     // Fetch teams related to these projects

//     const teams = await Team.find({ projectId: { $in: projectIds }, isDeleted: false });
 
//     // Flatten all team members

//     const allMembers = teams.flatMap(team => team.teamMembers);
 
//     // Fetch all taskIds from bugs to batch query tasks

//     const taskIds = bugs.map(bug => bug.taskRef);

//     const tasks = await Task.find({ task_id: { $in: taskIds } });
 
//     // Map for quick lookup

//     const taskMap = new Map(tasks.map(task => [task.task_id, task.reviewStatus]));
 
//     // Enrich bugs with assignedToDetails and reviewStatus

//     const enrichedBugs = bugs.map(bug => {

//       const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
//       return {

//         ...bug.toObject(),

//         assignedToDetails: assignedMember ? {

//           _id: assignedMember._id,

//           memberId: assignedMember.memberId,

//           memberName: assignedMember.memberName,

//           email: assignedMember.email,

//           role: assignedMember.role

//         } : null,

//         reviewStatus: taskMap.get(bug.taskRef) || 'N/A'  // fallback to 'N/A' if task not found

//       };

//     });
 
//     res.status(200).json({ success: true, data: enrichedBugs });
 
//   } catch (error) {

//     console.error('Error fetching bugs:', error);

//     res.status(500).json({ success: false, message: 'Server Error' });

//   }

// };

 exports.downloadBugsByProject = async (req, res) => {
  const { projectId } = req.params;
 
  try {
    // Step 1: Get all bugs by projectId
    const bugs = await Bug.find({ projectId }).sort({ createdAt: 1 });
 
    // Step 2: Get all teams in that project
    const teams = await Team.find({ projectId, isDeleted: false });
 
    // Step 3: Merge all teamMembers
    const allMembers = teams.flatMap(team => team.teamMembers);
 
    // Step 4: Enrich bugs with assignedTo details and reviewStatus
    const enrichedBugs = await Promise.all(
      bugs.map(async (bug) => {
        const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
        const task = await Task.findOne({ task_id: bug.taskRef });
 
        return {
          ...bug.toObject(),
          assignedToDetails: assignedMember
            ? {
                memberId: assignedMember.memberId,
                memberName: assignedMember.memberName,
                email: assignedMember.email,
                role: assignedMember.role,
              }
            : {
                memberId: bug.assignedTo,
                memberName: 'Not Found',
                email: 'N/A',
                role: 'N/A',
              },
          deadline: bug.deadline,
          reviewStatus: task?.reviewStatus || 'N/A',
        };
      })
    );
 
    // Step 5: Generate Excel
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Bugs');
 
    worksheet.columns = [
      { header: 'Bug ID', key: 'bug_id', width: 15 },
      { header: 'Title', key: 'title', width: 30 },
      { header: 'Description', key: 'description', width: 40 },
      { header: 'Task Ref', key: 'taskRef', width: 20 },
      { header: 'Assigned To', key: 'assignedToName', width: 25 },
      { header: 'Email', key: 'assignedToEmail', width: 30 },
      { header: 'Role', key: 'assignedToRole', width: 20 },
      { header: 'Priority', key: 'priority', width: 12 },
      { header: 'Deadline', key: 'deadline', width: 20 },
      { header: 'Review Status', key: 'reviewStatus', width: 20 },
      { header: 'Status', key: 'status', width: 12 },
      { header: 'Created At', key: 'createdAt', width: 25 },
      { header: 'Resolved At', key: 'resolvedAt', width: 25 },
 
    ];
 
    enrichedBugs.forEach(bug => {
      worksheet.addRow({
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        assignedToName: bug.assignedToDetails?.memberName || 'Unknown',
        assignedToEmail: bug.assignedToDetails?.email || 'N/A',
        assignedToRole: bug.assignedToDetails?.role || 'N/A',
        priority: bug.priority,
        status: bug.status,
        createdAt: bug.createdAt ? bug.createdAt.toISOString() : '',
        resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : '',
        deadline: bug.deadline ? new Date(bug.deadline).toISOString().split('T')[0] : 'N/A',
        reviewStatus: bug.reviewStatus,
      });
    });
 
    // Step 6: Send file
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=bugs_${projectId}.xlsx`
    );
 
    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    console.error('Error exporting bugs:', error);
    res.status(500).json({ message: 'Failed to export bugs', error: error.message });
  }
};
 
 
 
 
exports.downloadBugsByAssigneeAndProject = async (req, res) => {
  const { assignedTo, projectId } = req.params;
 
  try {
    // Step 1: Find bugs for the specific user and project
    const bugs = await Bug.find({ assignedTo, projectId }).sort({ createdAt: 1 });
 
    if (bugs.length === 0) {
      return res.status(404).json({ message: 'No bugs found for this user in this project' });
    }
 
    // Step 2: Get all teams in the project containing the member
    const teams = await Team.find({
      projectId,
      isDeleted: false,
      'teamMembers.memberId': assignedTo
    });
 
    // Step 3: Extract member details
    let assignedMember = null;
    for (const team of teams) {
      const match = team.teamMembers.find(member => member.memberId === assignedTo);
      if (match) {
        assignedMember = match;
        break;
      }
    }
 
    const assignedToDetails = assignedMember
      ? {
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role
        }
      : {
          memberId: assignedTo,
          memberName: 'Not Found',
          email: 'N/A',
          role: 'N/A'
        };
 
    // Step 4: Setup Excel file
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Bugs by Assignee');
 
    worksheet.columns = [
      { header: 'Bug ID', key: 'bug_id', width: 15 },
      { header: 'Title', key: 'title', width: 30 },
      { header: 'Description', key: 'description', width: 40 },
      { header: 'Task Ref', key: 'taskRef', width: 20 },
      { header: 'Assigned To Name', key: 'assignedToName', width: 25 },
      { header: 'Email', key: 'assignedToEmail', width: 30 },
      { header: 'Role', key: 'assignedToRole', width: 20 },
      { header: 'Priority', key: 'priority', width: 12 },
      { header: 'Deadline', key: 'deadline', width: 20 },
      { header: 'Task Review Status', key: 'reviewStatus', width: 20 },
      { header: 'Status', key: 'status', width: 12 },
      { header: 'Created At', key: 'createdAt', width: 25 },
      { header: 'Resolved At', key: 'resolvedAt', width: 25 },
 
    ];
 
    // Step 5: Add bug data
    for (const bug of bugs) {
      // Get the corresponding task to fetch reviewStatus
      const task = await Task.findOne({ task_id: bug.taskRef });
 
      worksheet.addRow({
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskRef: bug.taskRef,
        assignedToName: assignedToDetails.memberName,
        assignedToEmail: assignedToDetails.email,
        assignedToRole: assignedToDetails.role,
        priority: bug.priority,
        status: bug.status,
        createdAt: bug.createdAt?.toISOString(),
        resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : 'N/A',
        deadline: bug.deadline ? new Date(bug.deadline).toISOString().split('T')[0] : 'N/A',
        reviewStatus: task?.reviewStatus || 'N/A'
      });
    }
 
    // Step 6: Send the Excel file
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=bugs_${projectId}_${assignedTo}.xlsx`
    );
 
    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    console.error('Error exporting bugs by assignee and project:', error);
    res.status(500).json({ message: 'Failed to export bugs', error: error.message });
  }
};

// exports.downloadBugsByProject = async (req, res) => {
//   const { projectId } = req.params;
 
//   try {
//     // Step 1: Get all bugs by projectId
//     const bugs = await Bug.find({ projectId }).sort({ createdAt: 1 });
 
//     // Step 2: Get all teams in that project
//     const teams = await Team.find({ projectId, isDeleted: false });
 
//     // Step 3: Merge all teamMembers
//     const allMembers = teams.flatMap(team => team.teamMembers);
 
//     // Step 4: Enrich bugs with assignedTo details
//     const enrichedBugs = bugs.map(bug => {
//       const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);
 
//       return {
//         ...bug.toObject(),
//         assignedToDetails: assignedMember
//           ? {
//               memberId: assignedMember.memberId,
//               memberName: assignedMember.memberName,
//               email: assignedMember.email,
//               role: assignedMember.role,
//             }
//           : {
//               memberId: bug.assignedTo,
//               memberName: 'Not Found',
//               email: 'N/A',
//               role: 'N/A',
//             },
//       };
//     });
 
//     // Step 5: Generate Excel
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet('Bugs');
 
//     // Define Columns
//     worksheet.columns = [
//       { header: 'Bug ID', key: 'bug_id', width: 15 },
//       { header: 'Title', key: 'title', width: 30 },
//       { header: 'Description', key: 'description', width: 40 },
//       { header: 'Task Ref', key: 'taskRef', width: 20 },
//       { header: 'Assigned To', key: 'assignedToName', width: 25 },
//       { header: 'Email', key: 'assignedToEmail', width: 30 },
//       { header: 'Role', key: 'assignedToRole', width: 20 },
//       { header: 'Priority', key: 'priority', width: 12 },
//       { header: 'Status', key: 'status', width: 12 },
//       { header: 'Created At', key: 'createdAt', width: 25 },
//       { header: 'Resolved At', key: 'resolvedAt', width: 25 },
//     ];
 
//     // Add rows
//     enrichedBugs.forEach(bug => {
//       worksheet.addRow({
//         bug_id: bug.bug_id,
//         title: bug.title,
//         description: bug.description,
//         taskRef: bug.taskRef,
//         assignedToName: bug.assignedToDetails?.memberName || 'Unknown',
//         assignedToEmail: bug.assignedToDetails?.email || 'N/A',
//         assignedToRole: bug.assignedToDetails?.role || 'N/A',
//         priority: bug.priority,
//         status: bug.status,
//         createdAt: bug.createdAt ? bug.createdAt.toISOString() : '',
//         resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : '',
//       });
//     });
 
//     // Send file
//     res.setHeader(
//       'Content-Type',
//       'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
//     );
//     res.setHeader(
//       'Content-Disposition',
//       `attachment; filename=bugs_${projectId}.xlsx`
//     );
 
//     await workbook.xlsx.write(res);
//     res.status(200).end();
//   } catch (error) {
//     console.error('Error exporting bugs:', error);
//     res.status(500).json({ message: 'Failed to export bugs', error: error.message });
//   }
// };


// exports.downloadBugsByAssigneeAndProject = async (req, res) => {
//   const { assignedTo, projectId } = req.params;
 
//   try {
//     // Step 1: Find bugs for the specific user and project
//     const bugs = await Bug.find({ assignedTo, projectId }).sort({ createdAt: 1 });
 
//     if (bugs.length === 0) {
//       return res.status(404).json({ message: 'No bugs found for this user in this project' });
//     }
 
//     // Step 2: Get all teams in the project containing the member
//     const teams = await Team.find({
//       projectId,
//       isDeleted: false,
//       'teamMembers.memberId': assignedTo
//     });
 
//     // Step 3: Extract member details
//     let assignedMember = null;
//     for (const team of teams) {
//       const match = team.teamMembers.find(member => member.memberId === assignedTo);
//       if (match) {
//         assignedMember = match;
//         break;
//       }
//     }
 
//     const assignedToDetails = assignedMember
//       ? {
//           memberId: assignedMember.memberId,
//           memberName: assignedMember.memberName,
//           email: assignedMember.email,
//           role: assignedMember.role
//         }
//       : {
//           memberId: assignedTo,
//           memberName: 'Not Found',
//           email: 'N/A',
//           role: 'N/A'
//         };
 
//     // Step 4: Setup Excel file
//     const workbook = new ExcelJS.Workbook();
//     const worksheet = workbook.addWorksheet('Bugs by Assignee');
 
//     worksheet.columns = [
//       { header: 'Bug ID', key: 'bug_id', width: 15 },
//       { header: 'Title', key: 'title', width: 30 },
//       { header: 'Description', key: 'description', width: 40 },
//       { header: 'Task Ref', key: 'taskRef', width: 20 },
//       { header: 'Assigned To Name', key: 'assignedToName', width: 25 },
//       { header: 'Email', key: 'assignedToEmail', width: 30 },
//       { header: 'Role', key: 'assignedToRole', width: 20 },
//       { header: 'Priority', key: 'priority', width: 12 },
//       { header: 'Status', key: 'status', width: 12 },
//       { header: 'Created At', key: 'createdAt', width: 25 },
//       { header: 'Resolved At', key: 'resolvedAt', width: 25 }
//     ];
 
//     // Step 5: Add bug data
//     bugs.forEach(bug => {
//       worksheet.addRow({
//         bug_id: bug.bug_id,
//         title: bug.title,
//         description: bug.description,
//         taskRef: bug.taskRef,
//         assignedToName: assignedToDetails.memberName,
//         assignedToEmail: assignedToDetails.email,
//         assignedToRole: assignedToDetails.role,
//         priority: bug.priority,
//         status: bug.status,
//         createdAt: bug.createdAt?.toISOString(),
//         resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : 'N/A'
//       });
//     });
 
//     // Step 6: Send the Excel file
//     res.setHeader(
//       'Content-Type',
//       'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
//     );
//     res.setHeader(
//       'Content-Disposition',
//       `attachment; filename=bugs_${projectId}_${assignedTo}.xlsx`
//     );
 
//     await workbook.xlsx.write(res);
//     res.status(200).end();
//   } catch (error) {
//     console.error('Error exporting bugs by assignee and project:', error);
//     res.status(500).json({ message: 'Failed to export bugs', error: error.message });
//   }
// };
import ViewTask from "@/modules/task/ViewTask";

export default function Page() {
  return (
    <>
 
        <ViewTask/>
     
    </>
  );
}
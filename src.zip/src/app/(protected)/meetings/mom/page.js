import MomDashboardList from "@/modules/meetings/mom/momdashboardList";


export default function Page() {
  return (
    <>
      

<MomDashboardList/>

    </>
  );
}
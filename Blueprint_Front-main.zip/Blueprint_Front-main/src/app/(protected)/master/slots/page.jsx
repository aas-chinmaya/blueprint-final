
import SlotMaster from "@/modules/master/SlotMaster";



export default function page() {
 

  return (

  
      <SlotMaster/> 

  );
}

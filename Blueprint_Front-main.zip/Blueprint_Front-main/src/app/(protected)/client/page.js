"use client";
import AllClientList from "@/modules/clients/AllClientList";

export default function Page() {
  return (
    <>
     
        <AllClientList />
     
    </>
  );
}

import ContactsList from "@/modules/contact/ContactList";



export default function Page() {
  return (
    <>
     
       <ContactsList/>
     
    </>
  );
}




